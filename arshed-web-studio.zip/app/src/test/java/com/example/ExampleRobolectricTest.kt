package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Arshed Web Studio", appName)
  }

  @Test
  fun `verify web portfolio assets packaged`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val assetList = context.assets.list("www")?.toList() ?: emptyList()
    assertTrue("index.html must exist in www assets", assetList.contains("index.html"))
  }
}
