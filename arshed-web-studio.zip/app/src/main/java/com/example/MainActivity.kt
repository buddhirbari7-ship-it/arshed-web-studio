package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ViewCarousel
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AboutScreen
import com.example.ui.BeadStudioScreen
import com.example.ui.ContactScreen
import com.example.ui.HomeScreen
import com.example.ui.ProjectsScreen
import com.example.ui.ServicesScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val systemDark = isSystemInDarkTheme()
      var isDark by remember { mutableStateOf(systemDark) }

      MyApplicationTheme(darkTheme = isDark) {
        ArshedStudioApp(
          isDarkTheme = isDark,
          onToggleTheme = { isDark = !isDark }
        )
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArshedStudioApp(
  isDarkTheme: Boolean,
  onToggleTheme: () -> Unit
) {
  val context = LocalContext.current
  var selectedTab by remember { mutableIntStateOf(0) }
  var isBangla by remember { mutableStateOf(false) }

  // Handle system back button to pop to Home if on a sub-screen
  BackHandler(enabled = selectedTab != 0) {
    selectedTab = 0
  }

  Scaffold(
    contentWindowInsets = WindowInsets.safeDrawing,
    topBar = {
      TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.surface,
          titleContentColor = MaterialTheme.colorScheme.onSurface
        ),
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.primary),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "A",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
              )
            }
            Spacer(modifier = Modifier.size(10.dp))
            Column {
              Text(
                text = if (isBangla) "আরশেদ ওয়েব স্টুডিও" else "Arshed Web Studio",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = if (isBangla) "ফ্রিল্যান্সার পোর্টফোলিও" else "Freelancer.com Portfolio",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.secondary,
                fontSize = 11.sp
              )
            }
          }
        },
        actions = {
          // Language Toggle
          IconButton(
            onClick = { isBangla = !isBangla },
            modifier = Modifier.testTag("lang_toggle_btn")
          ) {
            Icon(
              imageVector = Icons.Default.Language,
              contentDescription = "Switch Language (English / Bangla)",
              tint = MaterialTheme.colorScheme.primary
            )
          }

          // Dark/Light Theme Toggle
          IconButton(
            onClick = onToggleTheme,
            modifier = Modifier.testTag("theme_toggle_btn")
          ) {
            Icon(
              imageVector = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
              contentDescription = "Toggle Theme"
            )
          }

          // Share Studio
          IconButton(
            onClick = {
              val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(
                  Intent.EXTRA_SUBJECT,
                  "Arshed Web Studio — Portfolio & Interactive Design Simulator"
                )
                putExtra(
                  Intent.EXTRA_TEXT,
                  "Explore Arshed Web Studio by Md Arshed Alam! Interactive Product Design Studio, School Management Dashboard, and responsive front-end projects: https://www.freelancer.com/u/arshedwebstudio"
                )
              }
              context.startActivity(Intent.createChooser(shareIntent, "Share Portfolio"))
            },
            modifier = Modifier.testTag("share_btn")
          ) {
            Icon(
              imageVector = Icons.Default.Share,
              contentDescription = "Share Portfolio"
            )
          }
        }
      )
    },
    bottomBar = {
      NavigationBar(
        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars),
        containerColor = MaterialTheme.colorScheme.surface
      ) {
        NavigationBarItem(
          selected = selectedTab == 0,
          onClick = { selectedTab = 0 },
          icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
          label = { Text(if (isBangla) "হোম" else "Home", fontSize = 11.sp) },
          modifier = Modifier.testTag("nav_home")
        )
        NavigationBarItem(
          selected = selectedTab == 1,
          onClick = { selectedTab = 1 },
          icon = { Icon(Icons.Default.ViewCarousel, contentDescription = "Projects") },
          label = { Text(if (isBangla) "প্রজেক্ট" else "Projects", fontSize = 11.sp) },
          modifier = Modifier.testTag("nav_projects")
        )
        NavigationBarItem(
          selected = selectedTab == 2,
          onClick = { selectedTab = 2 },
          icon = { Icon(Icons.Default.Palette, contentDescription = "Bead Studio") },
          label = { Text(if (isBangla) "স্টুডিও" else "Studio", fontSize = 11.sp) },
          modifier = Modifier.testTag("nav_studio")
        )
        NavigationBarItem(
          selected = selectedTab == 3,
          onClick = { selectedTab = 3 },
          icon = { Icon(Icons.Default.Business, contentDescription = "Services") },
          label = { Text(if (isBangla) "সার্ভিস" else "Services", fontSize = 11.sp) },
          modifier = Modifier.testTag("nav_services")
        )
        NavigationBarItem(
          selected = selectedTab == 4,
          onClick = { selectedTab = 4 },
          icon = { Icon(Icons.Default.Info, contentDescription = "About") },
          label = { Text(if (isBangla) "পরিচয়" else "About", fontSize = 11.sp) },
          modifier = Modifier.testTag("nav_about")
        )
        NavigationBarItem(
          selected = selectedTab == 5,
          onClick = { selectedTab = 5 },
          icon = { Icon(Icons.Default.Mail, contentDescription = "Contact") },
          label = { Text(if (isBangla) "যোগাযোগ" else "Contact", fontSize = 11.sp) },
          modifier = Modifier.testTag("nav_contact")
        )
      }
    }
  ) { innerPadding ->
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
      color = MaterialTheme.colorScheme.background
    ) {
      when (selectedTab) {
        0 -> HomeScreen(
          isBangla = isBangla,
          onNavigateToProjects = { selectedTab = 1 },
          onNavigateToBeadStudio = { selectedTab = 2 },
          onNavigateToContact = { selectedTab = 5 }
        )
        1 -> ProjectsScreen(
          isBangla = isBangla,
          onNavigateToBeadStudio = { selectedTab = 2 }
        )
        2 -> BeadStudioScreen(
          isBangla = isBangla
        )
        3 -> ServicesScreen(
          isBangla = isBangla
        )
        4 -> AboutScreen(
          isBangla = isBangla
        )
        5 -> ContactScreen(
          isBangla = isBangla
        )
      }
    }
  }
}
