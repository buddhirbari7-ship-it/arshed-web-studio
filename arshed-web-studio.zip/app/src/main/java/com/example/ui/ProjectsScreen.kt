package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.NewsArticle
import com.example.model.NoticeRecord
import com.example.model.ProjectItem
import com.example.model.StudentRecord
import com.example.model.TeacherRecord

@Composable
fun ProjectsScreen(
  isBangla: Boolean = false,
  onNavigateToBeadStudio: () -> Unit = {}
) {
  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf("All") }

  // Modals state
  var showSchoolModal by remember { mutableStateOf(false) }
  var showNewsModal by remember { mutableStateOf(false) }
  var activeCaseStudy by remember { mutableStateOf<ProjectItem?>(null) }

  val allProjects = remember {
    listOf(
      ProjectItem(
        id = "product-studio",
        title = "Interactive Product Design Studio",
        category = "Interactive Prototype",
        description = "A real-time jewelry & bead design emulator. Users dynamically select bead shapes, custom gemstone colors, adjust sizes, and reorder elements with instant SVG math and PNG export.",
        disclaimer = "Demonstration Notice: Real client-side interactive tool built to demonstrate SVG calculations and canvas export.",
        tags = listOf("SVG Geometry", "HTML5 Canvas", "Interactive UI", "State Engine")
      ),
      ProjectItem(
        id = "school-dashboard",
        title = "School Management Dashboard",
        category = "Dashboard UI",
        description = "A comprehensive educational administration interface featuring student & faculty attendance metrics, active notice broadcasting, and interactive searchable student rosters.",
        disclaimer = "Demonstration Notice: Concept demonstration project with simulated data; not connected to a live school database.",
        tags = listOf("Data Metrics", "Searchable Tables", "Tab Navigation", "Notice Board")
      ),
      ProjectItem(
        id = "news-portal",
        title = "Local News Portal (\"Metro Pulse\")",
        category = "Editorial & News",
        description = "A modern digital news homepage equipped with a breaking news ticker, instant category filtering (Politics, Business, Technology, Community, Sports), article search, and reading overlay.",
        disclaimer = "Demonstration Notice: Concept demonstration portal populated with sample journalistic content.",
        tags = listOf("Category Filter", "Breaking Ticker", "Editorial Layout", "Fast Load")
      )
    )
  }

  val filteredProjects = allProjects.filter { project ->
    val matchesCat = selectedCategory == "All" ||
      (selectedCategory == "Interactive" && project.category.contains("Interactive")) ||
      (selectedCategory == "Dashboard" && project.category.contains("Dashboard")) ||
      (selectedCategory == "Editorial" && project.category.contains("Editorial"))
    val matchesSearch = searchQuery.isEmpty() ||
      project.title.contains(searchQuery, ignoreCase = true) ||
      project.description.contains(searchQuery, ignoreCase = true)
    matchesCat && matchesSearch
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // Header
    Column {
      Text(
        text = if (isBangla) "নির্বাচিত পোর্টফোলিও প্রজেক্ট" else "Featured Portfolio Projects",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground
      )
      Text(
        text = if (isBangla) "ব্যবহারিক ফ্রন্ট-এন্ড কোডিং এবং রেসপনসিভ ইউআই-এর বাস্তব কেস স্টাডি" else "Practical demonstrations of custom front-end programming and responsive UI architecture.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.secondary
      )
    }

    // Search Bar
    OutlinedTextField(
      value = searchQuery,
      onValueChange = { searchQuery = it },
      modifier = Modifier
        .fillMaxWidth()
        .testTag("project_search_input"),
      placeholder = { Text(if (isBangla) "প্রজেক্ট খুঁজুন..." else "Search projects...") },
      leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
      trailingIcon = {
        if (searchQuery.isNotEmpty()) {
          IconButton(onClick = { searchQuery = "" }) {
            Icon(Icons.Default.Close, contentDescription = "Clear search")
          }
        }
      },
      singleLine = true,
      shape = RoundedCornerShape(12.dp)
    )

    // Category Filter Chips
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      listOf("All", "Interactive", "Dashboard", "Editorial").forEach { cat ->
        FilterChip(
          selected = selectedCategory == cat,
          onClick = { selectedCategory = cat },
          label = {
            Text(
              when (cat) {
                "All" -> if (isBangla) "সকল প্রজেক্ট" else "All"
                "Interactive" -> if (isBangla) "ইন্টারেক্টিভ" else "Interactive"
                "Dashboard" -> if (isBangla) "ড্যাশবোর্ড" else "Dashboard"
                else -> if (isBangla) "সংবাদ" else "Editorial"
              }
            )
          }
        )
      }
    }

    // Projects List
    LazyColumn(
      verticalArrangement = Arrangement.spacedBy(14.dp),
      modifier = Modifier.weight(1f)
    ) {
      items(filteredProjects) { project ->
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = project.category.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
            }

            Text(
              text = project.title,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )

            Text(
              text = project.description,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              lineHeight = 18.sp
            )

            // Disclaimer pill
            Surface(
              color = MaterialTheme.colorScheme.surfaceVariant,
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(
                text = project.disclaimer,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(8.dp),
                fontSize = 11.sp
              )
            }

            // Tags
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              project.tags.forEach { tag ->
                Surface(
                  color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                  shape = RoundedCornerShape(6.dp)
                ) {
                  Text(
                    text = tag,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              }
            }

            // Actions
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Button(
                onClick = {
                  when (project.id) {
                    "product-studio" -> onNavigateToBeadStudio()
                    "school-dashboard" -> showSchoolModal = true
                    "news-portal" -> showNewsModal = true
                  }
                },
                modifier = Modifier.weight(1f)
              ) {
                Text(if (isBangla) "ডেমো খুলুন" else "Open Demo")
              }

              OutlinedButton(
                onClick = { activeCaseStudy = project },
                modifier = Modifier.weight(1f)
              ) {
                Text(if (isBangla) "কেস স্টাডি" else "Case Study")
              }
            }
          }
        }
      }
    }
  }

  // School Dashboard Interactive Modal Dialog
  if (showSchoolModal) {
    SchoolDashboardDialog(
      onDismiss = { showSchoolModal = false },
      isBangla = isBangla
    )
  }

  // Local News Portal Interactive Modal Dialog
  if (showNewsModal) {
    NewsPortalDialog(
      onDismiss = { showNewsModal = false },
      isBangla = isBangla
    )
  }

  // Universal Case Study Modal Dialog
  activeCaseStudy?.let { project ->
    AlertDialog(
      onDismissRequest = { activeCaseStudy = null },
      title = { Text(project.title, fontWeight = FontWeight.Bold) },
      text = {
        Column(
          modifier = Modifier.verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Text(
            text = "Honest Demonstration Notice:",
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            style = MaterialTheme.typography.labelMedium
          )
          Text(project.disclaimer, style = MaterialTheme.typography.bodySmall)

          Text(
            text = "Architecture & Key Features:",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelMedium
          )
          project.tags.forEach { tag ->
            Text("• $tag: Cleanly modularized components without heavy framework baggage.")
          }

          Text(
            text = "Implementation Summary:",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelMedium
          )
          Text(project.description, style = MaterialTheme.typography.bodySmall)
        }
      },
      confirmButton = {
        TextButton(onClick = { activeCaseStudy = null }) {
          Text("Close")
        }
      }
    )
  }
}

@Composable
fun SchoolDashboardDialog(
  onDismiss: () -> Unit,
  isBangla: Boolean
) {
  var activeTab by remember { mutableIntStateOf(0) }
  var studentSearch by remember { mutableStateOf("") }

  val students = remember {
    listOf(
      StudentRecord("ST-101", "Tanvir Hossain", "Grade 10", "01", "Present", "96%"),
      StudentRecord("ST-102", "Nusrat Jahan", "Grade 10", "02", "Present", "98%"),
      StudentRecord("ST-103", "Arafat Rahman", "Grade 9", "05", "Late", "88%"),
      StudentRecord("ST-104", "Farhana Akhter", "Grade 10", "03", "Present", "95%"),
      StudentRecord("ST-105", "Sabbir Ahmed", "Grade 9", "12", "Absent", "82%")
    )
  }

  val notices = remember {
    mutableStateListOf(
      NoticeRecord("Annual Sports Day Schedule Announced", "Oct 14", "Event", "Track and field events start next Monday on central field."),
      NoticeRecord("Term Examination Advisory", "Oct 12", "Academic", "Admit cards distributed from administrative office."),
      NoticeRecord("Science Club Robotics Session", "Oct 10", "STEM", "Hands-on sensor programming in laboratory.")
    )
  }

  var newNoticeText by remember { mutableStateOf("") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(if (isBangla) "স্কুল ম্যানেজমেন্ট ড্যাশবোর্ড" else "School Management Dashboard", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close") }
      }
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Metric Cards
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text("94.2%", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
              Text("Attendance", fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
            }
          }
          Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text("1,240", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.onSecondaryContainer)
              Text("Students", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSecondaryContainer)
            }
          }
        }

        // Tabs
        TabRow(selectedTabIndex = activeTab) {
          Tab(selected = activeTab == 0, onClick = { activeTab = 0 }, text = { Text("Roster", fontSize = 12.sp) })
          Tab(selected = activeTab == 1, onClick = { activeTab = 1 }, text = { Text("Notices", fontSize = 12.sp) })
        }

        if (activeTab == 0) {
          OutlinedTextField(
            value = studentSearch,
            onValueChange = { studentSearch = it },
            placeholder = { Text("Search student name...", fontSize = 12.sp) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )

          students.filter { it.name.contains(studentSearch, ignoreCase = true) }.forEach { s ->
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(s.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                  Text("${s.grade} • Roll #${s.roll}", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                }
                Surface(
                  color = if (s.status == "Present") Color(0xFF2E7D32) else Color(0xFFC62828),
                  shape = RoundedCornerShape(12.dp)
                ) {
                  Text(s.status, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                }
              }
            }
          }
        } else {
          // Post Notice
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(
              value = newNoticeText,
              onValueChange = { newNoticeText = it },
              placeholder = { Text("New announcement...", fontSize = 12.sp) },
              modifier = Modifier.weight(1f),
              singleLine = true
            )
            Button(
              onClick = {
                if (newNoticeText.isNotBlank()) {
                  notices.add(0, NoticeRecord(newNoticeText, "Today", "Demo", "Notice broadcasted live."))
                  newNoticeText = ""
                }
              }
            ) {
              Text("Post")
            }
          }

          notices.forEach { n ->
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
              Column(modifier = Modifier.padding(8.dp)) {
                Text(n.title, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(n.content, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) { Text("Close") }
    }
  )
}

@Composable
fun NewsPortalDialog(
  onDismiss: () -> Unit,
  isBangla: Boolean
) {
  var selectedCat by remember { mutableStateOf("All") }
  val news = remember {
    listOf(
      NewsArticle(1, "High-Speed Green Metro Expansion to Riverfront Corridor", "Community", "2h ago", "City Desk", "Urban transit authority approved expansion.", "The urban transit authority has secured final civic approval to extend the rapid transit corridor by 8 kilometers with zero-emission electric rolling stock."),
      NewsArticle(2, "Local Tech Incubator Launches Digital Skills Accelerator", "Technology", "4h ago", "Tech Reporter", "200 students gain UI/UX web development mentorship.", "Over 200 secondary and college students will gain hands-on training in web design, UI/UX architecture, and open-source tooling through a grant partnership."),
      NewsArticle(3, "Regional Farmers Market Expands Organic Produce Hub", "Business", "6h ago", "Agriculture Desk", "Record harvests with digital contactless payment.", "Local organic growers celebrate record harvests and unveil contactless digital payment options at downtown community stalls.")
    )
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("Metro Pulse News (Interactive Demo)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close") }
      }
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Breaking Ticker
        Surface(
          color = MaterialTheme.colorScheme.primary,
          shape = RoundedCornerShape(6.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = "BREAKING: Green Metro Transit Line Extension Approved",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            modifier = Modifier.padding(6.dp)
          )
        }

        // Category Filter
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf("All", "Community", "Technology", "Business").forEach { cat ->
            FilterChip(
              selected = selectedCat == cat,
              onClick = { selectedCat = cat },
              label = { Text(cat, fontSize = 11.sp) }
            )
          }
        }

        news.filter { selectedCat == "All" || it.category == selectedCat }.forEach { article ->
          Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
          ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Text("${article.category} • ${article.time}", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
              Text(article.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
              Text(article.content, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) { Text("Close") }
    }
  )
}
