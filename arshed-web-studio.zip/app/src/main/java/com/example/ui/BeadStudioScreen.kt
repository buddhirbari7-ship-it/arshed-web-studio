package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BeadItem
import com.example.model.BeadShape
import com.example.model.GemstoneColors
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun BeadStudioScreen(
  isBangla: Boolean = false
) {
  val context = LocalContext.current

  // Starter beads pattern (Azure Ocean preset)
  val beads = remember {
    mutableStateListOf(
      BeadItem(shape = BeadShape.SPHERE, color = Color(0xFF1565C0), sizeDp = 22f),
      BeadItem(shape = BeadShape.SPACER, color = Color(0xFFC0C0C0), sizeDp = 16f),
      BeadItem(shape = BeadShape.OVAL, color = Color(0xFF00ACC1), sizeDp = 24f),
      BeadItem(shape = BeadShape.SPACER, color = Color(0xFFC0C0C0), sizeDp = 16f),
      BeadItem(shape = BeadShape.SPHERE, color = Color(0xFFF5F5F5), sizeDp = 20f),
      BeadItem(shape = BeadShape.DIAMOND, color = Color(0xFF283593), sizeDp = 22f),
      BeadItem(shape = BeadShape.SPHERE, color = Color(0xFFF5F5F5), sizeDp = 20f),
      BeadItem(shape = BeadShape.SPACER, color = Color(0xFFC0C0C0), sizeDp = 16f),
      BeadItem(shape = BeadShape.OVAL, color = Color(0xFF00ACC1), sizeDp = 24f),
      BeadItem(shape = BeadShape.SPACER, color = Color(0xFFC0C0C0), sizeDp = 16f),
      BeadItem(shape = BeadShape.SPHERE, color = Color(0xFF1565C0), sizeDp = 22f),
      BeadItem(shape = BeadShape.STAR, color = Color(0xFFD4AF37), sizeDp = 24f),
      BeadItem(shape = BeadShape.SPHERE, color = Color(0xFF1565C0), sizeDp = 22f),
      BeadItem(shape = BeadShape.SPACER, color = Color(0xFFC0C0C0), sizeDp = 16f)
    )
  }

  var selectedIndex by remember { mutableIntStateOf(0) }
  var currentShape by remember { mutableStateOf(BeadShape.SPHERE) }
  var currentColor by remember { mutableStateOf(Color(0xFF1565C0)) }
  var isAnimating by remember { mutableStateOf(false) }

  // Rotation animation
  val infiniteTransition = rememberInfiniteTransition(label = "beadRotation")
  val animatedAngle by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 12000, easing = LinearEasing)
    ),
    label = "rotationAngle"
  )

  val rotationAngle = if (isAnimating) animatedAngle else 0f
  val scrollState = rememberScrollState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(scrollState)
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header & Metrics Bar
    Card(
      modifier = Modifier.fillMaxWidth(),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = if (isBangla) "ইন্টারেক্টিভ বিড স্টুডিও" else "Interactive Bead Studio",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = if (isBangla) "কাস্টম জুয়েলারি ও ব্রেসলেট ডিজাইন" else "Dynamic jewelry & bracelet designer",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.secondary
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.primaryContainer,
            modifier = Modifier.padding(2.dp)
          ) {
            Text(
              text = if (isBangla) "মোট বিড: ${beads.size}" else "Beads: ${beads.size}",
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onPrimaryContainer
            )
          }

          IconButton(
            onClick = { isAnimating = !isAnimating },
            modifier = Modifier.size(36.dp)
          ) {
            Icon(
              imageVector = if (isAnimating) Icons.Default.Stop else Icons.Default.PlayArrow,
              contentDescription = "Toggle Animation",
              tint = MaterialTheme.colorScheme.primary
            )
          }
        }
      }
    }

    // Central Interactive Canvas
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .aspectRatio(1f),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
      elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
      shape = RoundedCornerShape(20.dp)
    ) {
      Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        if (beads.isEmpty()) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
              text = if (isBangla) "ক্যানভাস ফাঁকা" else "Canvas is Empty",
              style = MaterialTheme.typography.titleMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            Button(
              onClick = {
                beads.addAll(
                  listOf(
                    BeadItem(shape = BeadShape.SPHERE, color = Color(0xFF1565C0), sizeDp = 22f),
                    BeadItem(shape = BeadShape.OVAL, color = Color(0xFF00ACC1), sizeDp = 24f),
                    BeadItem(shape = BeadShape.STAR, color = Color(0xFFD4AF37), sizeDp = 24f),
                    BeadItem(shape = BeadShape.SPHERE, color = Color(0xFF2E7D32), sizeDp = 22f)
                  )
                )
                selectedIndex = 0
              }
            ) {
              Text(if (isBangla) "স্টার্টার বিড যোগ করুন" else "Add Starter Beads")
            }
          }
        } else {
          Canvas(
            modifier = Modifier
              .fillMaxSize()
              .padding(24.dp)
              .testTag("bead_canvas")
              .pointerInput(beads.size, rotationAngle) {
                detectTapGestures { tapOffset ->
                  val center = Offset(size.width / 2f, size.height / 2f)
                  val minDim = minOf(size.width, size.height).toFloat()
                  val radius = minDim / 2f - 40f
                  val count = beads.size

                  // Check which bead was tapped
                  for (i in 0 until count) {
                    val angle = (i.toFloat() / count) * 2 * PI.toFloat() - (PI.toFloat() / 2) + (rotationAngle * PI.toFloat() / 180f)
                    val bx = center.x + radius * cos(angle)
                    val by = center.y + radius * sin(angle)
                    val beadRadius = beads[i].sizeDp * 1.5f

                    val dist = (tapOffset.x - bx) * (tapOffset.x - bx) + (tapOffset.y - by) * (tapOffset.y - by)
                    val threshold = (beadRadius * beadRadius * 2f)
                    if (dist.compareTo(threshold) <= 0) {
                      selectedIndex = i
                      break
                    }
                  }
                }
              }
          ) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val radius = size.minDimension / 2f - 40f
            val count = beads.size

            // Draw Strand String
            drawCircle(
              color = Color(0xFF94A3B8),
              radius = radius,
              center = center,
              style = Stroke(width = 4.dp.toPx())
            )

            // Draw Beads
            for (i in 0 until count) {
              val bead = beads[i]
              val angle = (i.toFloat() / count) * 2 * PI.toFloat() - (PI.toFloat() / 2) + (rotationAngle * PI.toFloat() / 180f)
              val bx = center.x + radius * cos(angle)
              val by = center.y + radius * sin(angle)
              val bCenter = Offset(bx, by)
              val beadRadius = bead.sizeDp * 1.3f
              val isSelected = i == selectedIndex

              // Selection ring
              if (isSelected) {
                drawCircle(
                  color = Color(0xFFFFD700),
                  radius = beadRadius + 8.dp.toPx(),
                  center = bCenter,
                  style = Stroke(width = 3.dp.toPx())
                )
              }

              // Radial gradient shader for realistic 3D sphere look
              val gradient = Brush.radialGradient(
                colors = listOf(
                  Color.White,
                  bead.color,
                  bead.color.copy(alpha = 0.85f),
                  Color.Black.copy(alpha = 0.4f)
                ),
                center = Offset(bx - beadRadius * 0.3f, by - beadRadius * 0.3f),
                radius = beadRadius * 1.2f
              )

              when (bead.shape) {
                BeadShape.OVAL -> {
                  drawOval(
                    brush = gradient,
                    topLeft = Offset(bx - beadRadius * 1.2f, by - beadRadius * 0.8f),
                    size = Size(beadRadius * 2.4f, beadRadius * 1.6f)
                  )
                }
                BeadShape.DIAMOND -> {
                  val path = Path().apply {
                    moveTo(bx, by - beadRadius * 1.2f)
                    lineTo(bx + beadRadius * 1.1f, by)
                    lineTo(bx, by + beadRadius * 1.2f)
                    lineTo(bx - beadRadius * 1.1f, by)
                    close()
                  }
                  drawPath(path = path, brush = gradient)
                }
                BeadShape.CUBE -> {
                  drawRoundRect(
                    brush = gradient,
                    topLeft = Offset(bx - beadRadius * 0.85f, by - beadRadius * 0.85f),
                    size = Size(beadRadius * 1.7f, beadRadius * 1.7f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
                  )
                }
                BeadShape.STAR -> {
                  val path = Path().apply {
                    val outer = beadRadius * 1.3f
                    val inner = beadRadius * 0.6f
                    for (step in 0 until 10) {
                      val r = if (step % 2 == 0) outer else inner
                      val a = (step * PI / 5).toFloat() - (PI / 2).toFloat()
                      val px = bx + r * cos(a)
                      val py = by + r * sin(a)
                      if (step == 0) moveTo(px, py) else lineTo(px, py)
                    }
                    close()
                  }
                  drawPath(path = path, brush = gradient)
                }
                BeadShape.HEART -> {
                  val path = Path().apply {
                    val s = beadRadius * 0.9f
                    moveTo(bx, by + s * 0.9f)
                    cubicTo(bx - s * 1.3f, by - 0.2f * s, bx - s * 1.3f, by - s * 0.9f, bx, by - s * 0.4f)
                    cubicTo(bx + s * 1.3f, by - s * 0.9f, bx + s * 1.3f, by - 0.2f * s, bx, by + s * 0.9f)
                    close()
                  }
                  drawPath(path = path, brush = gradient)
                }
                BeadShape.SPACER -> {
                  drawCircle(brush = gradient, radius = beadRadius * 0.7f, center = bCenter)
                  drawCircle(color = Color(0xFF1E293B), radius = beadRadius * 0.25f, center = bCenter)
                }
                BeadShape.SPHERE -> {
                  drawCircle(brush = gradient, radius = beadRadius, center = bCenter)
                  // Specular shine dot
                  drawCircle(
                    color = Color.White.copy(alpha = 0.7f),
                    radius = beadRadius * 0.25f,
                    center = Offset(bx - beadRadius * 0.35f, by - beadRadius * 0.35f)
                  )
                }
              }
            }
          }
        }
      }
    }

    // Shape Selection Row
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
      Text(
        text = if (isBangla) "বিডের আকৃতি নির্বাচন" else "Bead Shape",
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold
      )
      Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        BeadShape.values().forEach { shape ->
          FilterChip(
            selected = currentShape == shape,
            onClick = {
              currentShape = shape
              if (beads.isNotEmpty() && selectedIndex >= 0 && selectedIndex < beads.size) {
                beads[selectedIndex] = beads[selectedIndex].copy(shape = shape)
              }
            },
            label = { Text(shape.name.lowercase().replaceFirstChar { it.uppercase() }) },
            modifier = Modifier.testTag("shape_${shape.name.lowercase()}")
          )
        }
      }
    }

    // Gemstone Color Palette Swatches
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
      Text(
        text = if (isBangla) "রত্ন ও মেটেরিয়াল রঙ" else "Gemstone Color",
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold
      )
      Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        GemstoneColors.forEach { (color, name) ->
          Box(
            modifier = Modifier
              .size(38.dp)
              .clip(CircleShape)
              .background(color)
              .border(
                width = if (currentColor == color) 3.dp else 1.dp,
                color = if (currentColor == color) MaterialTheme.colorScheme.primary else Color.Black.copy(alpha = 0.2f),
                shape = CircleShape
              )
              .clickable {
                currentColor = color
                if (beads.isNotEmpty() && selectedIndex >= 0 && selectedIndex < beads.size) {
                  beads[selectedIndex] = beads[selectedIndex].copy(color = color)
                }
              }
          )
        }
      }
    }

    // Selected Bead Size Slider & Reorder
    if (beads.isNotEmpty() && selectedIndex >= 0 && selectedIndex < beads.size) {
      val selectedBead = beads[selectedIndex]
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(
          modifier = Modifier.padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = if (isBangla) "নির্বাচিত বিড #${selectedIndex + 1} (${selectedBead.shape})" else "Selected Bead #${selectedIndex + 1} (${selectedBead.shape})",
              fontWeight = FontWeight.Bold,
              style = MaterialTheme.typography.bodyMedium
            )
            Box(
              modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(selectedBead.color)
            )
          }

          // Size Slider
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = if (isBangla) "আকার: ${selectedBead.sizeDp.toInt()}dp" else "Size: ${selectedBead.sizeDp.toInt()}dp",
              style = MaterialTheme.typography.bodySmall,
              modifier = Modifier.width(90.dp)
            )
            Slider(
              value = selectedBead.sizeDp,
              onValueChange = { newSize ->
                beads[selectedIndex] = selectedBead.copy(sizeDp = newSize)
              },
              valueRange = 14f..32f,
              modifier = Modifier.weight(1f)
            )
          }

          // Reorder Controls
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedButton(
              onClick = {
                if (beads.size > 1) {
                  val target = (selectedIndex - 1 + beads.size) % beads.size
                  val temp = beads[selectedIndex]
                  beads[selectedIndex] = beads[target]
                  beads[target] = temp
                  selectedIndex = target
                }
              },
              modifier = Modifier.weight(1f)
            ) {
              Icon(Icons.Default.ArrowBack, contentDescription = "Move Left", modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(if (isBangla) "বামে সরান" else "Move Left", fontSize = 12.sp)
            }

            OutlinedButton(
              onClick = {
                if (beads.size > 1) {
                  val target = (selectedIndex + 1) % beads.size
                  val temp = beads[selectedIndex]
                  beads[selectedIndex] = beads[target]
                  beads[target] = temp
                  selectedIndex = target
                }
              },
              modifier = Modifier.weight(1f)
            ) {
              Text(if (isBangla) "ডানে সরান" else "Move Right", fontSize = 12.sp)
              Spacer(modifier = Modifier.width(4.dp))
              Icon(Icons.Default.ArrowForward, contentDescription = "Move Right", modifier = Modifier.size(16.dp))
            }
          }
        }
      }
    }

    // Action Buttons Grid
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Button(
        onClick = {
          if (beads.size < 32) {
            val insertIdx = if (beads.isEmpty()) 0 else selectedIndex + 1
            beads.add(
              insertIdx,
              BeadItem(shape = currentShape, color = currentColor, sizeDp = 22f)
            )
            selectedIndex = insertIdx
          } else {
            Toast.makeText(context, "Maximum 32 beads limit reached", Toast.LENGTH_SHORT).show()
          }
        },
        modifier = Modifier.weight(1f),
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
      ) {
        Icon(Icons.Default.Add, contentDescription = "Add Bead")
        Spacer(modifier = Modifier.width(4.dp))
        Text(if (isBangla) "বিড যোগ করুন" else "Add Bead")
      }

      OutlinedButton(
        onClick = {
          if (beads.isNotEmpty()) {
            beads.removeAt(selectedIndex)
            selectedIndex = if (beads.isEmpty()) 0 else (selectedIndex % beads.size)
          }
        },
        modifier = Modifier.weight(1f),
        enabled = beads.isNotEmpty()
      ) {
        Icon(Icons.Default.Delete, contentDescription = "Remove Bead")
        Spacer(modifier = Modifier.width(4.dp))
        Text(if (isBangla) "মুছুন" else "Remove")
      }
    }

    // Secondary Actions (Randomize, Copy Summary, Clear)
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      OutlinedButton(
        onClick = {
          beads.clear()
          val shapes = BeadShape.values()
          val count = 12 + (0..6).random()
          for (i in 0 until count) {
            val isSpacer = i % 2 == 1 && (0..10).random() > 4
            beads.add(
              BeadItem(
                shape = if (isSpacer) BeadShape.SPACER else shapes.random(),
                color = if (isSpacer) Color(0xFFD4AF37) else GemstoneColors.random().first,
                sizeDp = if (isSpacer) 16f else (20..26).random().toFloat()
              )
            )
          }
          selectedIndex = 0
          Toast.makeText(context, "Random pattern generated!", Toast.LENGTH_SHORT).show()
        },
        modifier = Modifier.weight(1f)
      ) {
        Icon(Icons.Default.AutoAwesome, contentDescription = "Randomize", modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(if (isBangla) "র‍্যান্ডম" else "Randomize", fontSize = 12.sp)
      }

      OutlinedButton(
        onClick = {
          val summary = buildString {
            appendLine("Arshed Web Studio — Bead Design Specs")
            appendLine("Total Beads: ${beads.size}")
            beads.forEachIndexed { idx, b ->
              appendLine("#${idx + 1}: ${b.shape.name} (${b.sizeDp.toInt()}dp)")
            }
          }
          val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
          clipboard.setPrimaryClip(ClipData.newPlainText("Bead Design", summary))
          Toast.makeText(context, "Design summary copied to clipboard!", Toast.LENGTH_SHORT).show()
        },
        modifier = Modifier.weight(1f)
      ) {
        Icon(Icons.Default.ContentCopy, contentDescription = "Copy Summary", modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(if (isBangla) "সামারি কপি" else "Copy Specs", fontSize = 12.sp)
      }

      OutlinedButton(
        onClick = {
          beads.clear()
          selectedIndex = 0
        },
        modifier = Modifier.weight(0.7f)
      ) {
        Text(if (isBangla) "খালি" else "Clear", fontSize = 12.sp)
      }
    }
  }
}
