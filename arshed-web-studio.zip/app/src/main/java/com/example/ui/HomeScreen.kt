package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DesignServices
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun HomeScreen(
  isBangla: Boolean = false,
  onNavigateToProjects: () -> Unit = {},
  onNavigateToBeadStudio: () -> Unit = {},
  onNavigateToContact: () -> Unit = {}
) {
  val scrollState = rememberScrollState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(scrollState)
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(18.dp)
  ) {
    // Hero Badge
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.primaryContainer,
      modifier = Modifier.padding(top = 8.dp)
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Icon(
          Icons.Default.AutoAwesome,
          contentDescription = null,
          modifier = Modifier.size(16.dp),
          tint = MaterialTheme.colorScheme.primary
        )
        Text(
          text = if (isBangla) "ফ্রিল্যান্স ওয়েব ডিজাইনার ও এআই-সহযোগী ডেভেলপার" else "Freelance Web Designer & AI-Assisted Developer",
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.primary
        )
      }
    }

    // Headline
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
      Text(
        text = if (isBangla) "ওয়েবসাইট যা শুধু দেখতে সুন্দর নয়," else "Websites That Do More",
        style = MaterialTheme.typography.headlineMedium,
        fontWeight = FontWeight.ExtraBold,
        color = MaterialTheme.colorScheme.onBackground
      )
      Text(
        text = if (isBangla) "বরং কার্যকরী ও ইন্টারেক্টিভ।" else "Than Look Good.",
        style = MaterialTheme.typography.headlineMedium,
        fontWeight = FontWeight.ExtraBold,
        color = MaterialTheme.colorScheme.primary
      )
      Text(
        text = if (isBangla) "রেসপনসিভ ওয়েব ডিজাইন | ইন্টারেক্টিভ প্রোটোটাইপ | এআই-সহায়তা ভিত্তিক ডেভেলপমেন্ট" else "Responsive Web Design | Interactive Prototypes | AI-Assisted Development",
        style = MaterialTheme.typography.bodySmall,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.secondary
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = if (isBangla) "আমি মো. আরশেদ আলম। ক্লায়েন্টদের জন্য মানসম্মত, দ্রুতগতির এবং পরিষ্কার কোডযুক্ত ডিজিটাল সল্যুশন তৈরি করি।" else "Hi, I'm Md Arshed Alam. I build responsive web interfaces, interactive client-side simulators, and functional prototypes designed for clarity, performance, and real user engagement.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 20.sp
      )
    }

    // Call to Action Buttons
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Button(
        onClick = onNavigateToProjects,
        modifier = Modifier.weight(1f),
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
      ) {
        Text(if (isBangla) "প্রজেক্ট দেখুন" else "View Projects")
      }

      Button(
        onClick = onNavigateToBeadStudio,
        modifier = Modifier.weight(1f),
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
      ) {
        Text(if (isBangla) "বিড স্টুডিও ডেমো" else "Try Bead Demo")
      }
    }

    // Interactive Teaser Card
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = if (isBangla) "লাইভ ক্যানভাস ইঞ্জিন প্রিভিউ" else "Live Canvas Engine Teaser",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
          Surface(
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text(
              text = "60 FPS Native",
              color = MaterialTheme.colorScheme.primary,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
        }

        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(180.dp),
          contentAlignment = Alignment.Center
        ) {
          Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val radius = 65.dp.toPx()
            val colors = listOf(
              Color(0xFF1565C0), Color(0xFFC0C0C0), Color(0xFF00ACC1),
              Color(0xFFD4AF37), Color(0xFF2E7D32), Color(0xFFC62828),
              Color(0xFF7B1FA2), Color(0xFFF5F5F5), Color(0xFF1565C0)
            )

            drawCircle(
              color = Color(0xFFCBD5E1),
              radius = radius,
              center = center,
              style = Stroke(width = 3.dp.toPx())
            )

            val count = colors.size
            for (i in 0 until count) {
              val angle = (i.toFloat() / count) * 2 * PI.toFloat() - (PI.toFloat() / 2)
              val bx = center.x + radius * cos(angle)
              val by = center.y + radius * sin(angle)
              drawCircle(
                color = colors[i],
                radius = 10.dp.toPx(),
                center = Offset(bx, by)
              )
            }
          }
        }

        OutlinedButton(
          onClick = onNavigateToBeadStudio,
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(if (isBangla) "সম্পূর্ণ বিড ডিজাইন স্টুডিও খুলুন →" else "Open Full Design Studio →")
        }
      }
    }

    // Key Highlights Grid
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Card(
        modifier = Modifier.weight(1f),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Text("100%", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
          Text(if (isBangla) "বাস্তব কোড ডেমো" else "Working Code", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }

      Card(
        modifier = Modifier.weight(1f),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Text("0", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = MaterialTheme.colorScheme.secondary)
          Text(if (isBangla) "পেইড এপিআই ডিপেনডেন্সি" else "Paid APIs", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }

      Card(
        modifier = Modifier.weight(1f),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Text("Fast", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurface)
          Text(if (isBangla) "হালকা ও প্রতিক্রিয়াশীল" else "Lightweight", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }
    }

    // Contact shortcut
    OutlinedButton(
      onClick = onNavigateToContact,
      modifier = Modifier.fillMaxWidth()
    ) {
      Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(16.dp))
      Spacer(modifier = Modifier.width(6.dp))
      Text(if (isBangla) "যোগাযোগ করুন বা ফ্রিল্যান্সার প্রোফাইল দেখুন" else "Get in Touch / View Freelancer Profile")
    }
  }
}
