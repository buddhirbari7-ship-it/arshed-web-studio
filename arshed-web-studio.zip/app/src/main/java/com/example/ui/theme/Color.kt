package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Arshed Web Studio Brand Palette
val BrandBluePrimary = Color(0xFF1565C0)
val BrandBluePrimaryDark = Color(0xFF90CAF9)
val BrandGreenAccent = Color(0xFF2E7D32)
val BrandGreenAccentDark = Color(0xFFA5D6A7)

val DarkSurface = Color(0xFF0F172A)
val DarkBackground = Color(0xFF0B1120)
val LightSurface = Color(0xFFF8FAFC)
val LightBackground = Color(0xFFFFFFFF)
