package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ServiceItem

@Composable
fun ServicesScreen(
  isBangla: Boolean = false
) {
  val services = remember {
    listOf(
      ServiceItem("Responsive Website Design", "Mobile-first, clean HTML5/CSS3 layouts that adapt seamlessly across all smartphone, tablet, and widescreen monitors.", "100% Mobile & Tablet Tested"),
      ServiceItem("Landing Page Development", "High-converting, fast-loading landing pages with clear call-to-actions and clean visual hierarchy.", "Lightweight & Fast Load"),
      ServiceItem("Interactive Website Prototypes", "Working JavaScript digital prototypes and product design simulators for real client testing.", "Real Interactive Logic"),
      ServiceItem("Dashboard UI Development", "Administrative and management interfaces featuring attendance metrics, dynamic tables, and filtering.", "Clean Tabular Layouts"),
      ServiceItem("School & Institutional Interfaces", "Academic web portals with notice boards, student rosters, faculty lists, and announcements.", "Intuitive Academic Portals"),
      ServiceItem("Website Redesign", "Modernizing legacy web layouts with upgraded typography, color palettes, and modern accessibility standards.", "Preserves Core Identity"),
      ServiceItem("AI-Assisted Web Development", "Pragmatically leveraging modern AI tools to accelerate code generation, prototyping, and debugging.", "Accelerated Delivery"),
      ServiceItem("Basic Firebase Integration", "Connecting web front-ends with fundamental Firebase Firestore schemas, authentication, and hosting.", "Solid Cloud Foundation")
    )
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Column(modifier = Modifier.padding(bottom = 8.dp)) {
        Text(
          text = if (isBangla) "আমার প্রদেয় সার্ভিসসমূহ" else "Services I Offer",
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onBackground
        )
        Text(
          text = if (isBangla) "ব্যবসা ও ক্লায়েন্টদের জন্য মানসম্মত, আধুনিক ও রেসপনসিভ সল্যুশন" else "Clear, modern web design and front-end development tailored for businesses and clients.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.secondary
        )
      }
    }

    items(services) { service ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Text(
            text = service.title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = service.description,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 18.sp
          )
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(16.dp))
            Text(
              text = service.perk,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.secondary
            )
          }
        }
      }
    }
  }
}

@Composable
fun AboutScreen(
  isBangla: Boolean = false
) {
  val scrollState = rememberScrollState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(scrollState)
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Avatar Card
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(18.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Box(
          modifier = Modifier
            .size(90.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primary),
          contentAlignment = Alignment.Center
        ) {
          Text("AA", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 32.sp)
        }

        Text("Md Arshed Alam", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(
          text = if (isBangla) "ফ্রিল্যান্স ওয়েব ডিজাইনার ও ডেভেলপার | আরশেদ ওয়েব স্টুডিও" else "Freelance Web Designer & Developer | Arshed Web Studio",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.primary,
          fontWeight = FontWeight.SemiBold
        )

        Surface(
          color = MaterialTheme.colorScheme.primaryContainer,
          shape = RoundedCornerShape(12.dp)
        ) {
          Text(
            text = "✓ Verified Freelancer.com Portfolio Showcase",
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
          )
        }
      }
    }

    // Honest Bio Card
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Text(
          text = if (isBangla) "আমার সম্পর্কে" else "About Md Arshed Alam",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = if (isBangla)
            "আমি একজন ফ্রিল্যান্স ওয়েব ডিজাইনার এবং ফ্রন্ট-এন্ড ডেভেলপার। আধুনিক ওয়েব স্ট্যান্ডার্ডের পাশাপাশি আমি ব্যবহারিক এআই-সহায়ক টুল ব্যবহার করি। এর ফলে জটিল ইন্টারফেস দ্রুত প্রোটোটাইপ করা এবং ক্লায়েন্টদের জন্য মানসম্মত কোড ডেলিভারি দেওয়া সম্ভব হয়।"
          else
            "I am a freelance web designer and front-end developer passionate about creating responsive, interactive, and cleanly structured web experiences.\n\nIn my daily development, I thoughtfully embrace modern AI-assisted workflows alongside core HTML5, CSS3, and JavaScript standards. This allows me to prototype complex interactive concepts rapidly, write cleaner code, and deliver polished web solutions on time without cutting corners on design principles.",
          style = MaterialTheme.typography.bodySmall,
          lineHeight = 20.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    // Core Principles Grid
    Text(
      text = if (isBangla) "মূল নীতিমালা" else "Core Principles",
      style = MaterialTheme.typography.titleSmall,
      fontWeight = FontWeight.Bold
    )

    listOf(
      "Transparent & Honest" to "I clearly define deliverables, concept demos, and technical tools with zero exaggerated claims.",
      "Performance-Minded" to "Lightweight asset footprints, semantic markup, and zero bloated script overhead.",
      "Mobile-First Always" to "Rigorous touch-target precision and fluid scaling across any screen width.",
      "Accessible by Design" to "High-contrast compliance, clear focus states, and dual English & Bangla linguistic support."
    ).forEach { (title, desc) ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.height(2.dp))
          Text(desc, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }
    }
  }
}

@Composable
fun ContactScreen(
  isBangla: Boolean = false
) {
  val context = LocalContext.current
  val scrollState = rememberScrollState()

  var name by remember { mutableStateOf("") }
  var email by remember { mutableStateOf("") }
  var message by remember { mutableStateOf("") }
  var submissionNotice by remember { mutableStateOf<String?>(null) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(scrollState)
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    Column {
      Text(
        text = if (isBangla) "যোগাযোগ করুন" else "Let's Build Something Great",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold
      )
      Text(
        text = if (isBangla) "আপনার নতুন প্রজেক্ট বা কাস্টম ডিজাইন সিমুলেটর নিয়ে কথা বলতে বার্তা পাঠান।" else "Have a project in mind or want to discuss a custom design simulator? Reach out today.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.secondary
      )
    }

    // Direct Action Buttons
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
      Column(
        modifier = Modifier.padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("contact@arshedwebstudio.com", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(if (isBangla) "সরাসরি স্টুডিও ইমেইল" else "Direct studio email inbox", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
          }
          IconButton(
            onClick = {
              val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
              clipboard.setPrimaryClip(ClipData.newPlainText("Email", "contact@arshedwebstudio.com"))
              Toast.makeText(context, "Email copied to clipboard!", Toast.LENGTH_SHORT).show()
            }
          ) {
            Icon(Icons.Default.ContentCopy, contentDescription = "Copy Email", tint = MaterialTheme.colorScheme.primary)
          }
        }

        OutlinedButton(
          onClick = {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.freelancer.com/u/arshedwebstudio"))
            context.startActivity(intent)
          },
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(Icons.Default.OpenInBrowser, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(if (isBangla) "ফ্রিল্যান্সার প্রোফাইল খুলুন" else "Open Freelancer.com Profile")
        }
      }
    }

    // Demo Notice Pill
    Surface(
      color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
      shape = RoundedCornerShape(10.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Text(
        text = if (isBangla)
          "সতর্কতা: নিচের ফর্মটি ক্লায়েন্ট-সাইড ভ্যালিডেশন ডেমো হিসেবে পরিচালিত। সরাসরি মেসেজ পাঠাতে উপরের কপি ইমেইল বা ফ্রিল্যান্সার লিঙ্ক ব্যবহার করুন।"
        else
          "Notice: This contact form runs client-side validation. To send an actual inquiry, use the Copy Email button or click to connect on Freelancer.com.",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(10.dp),
        fontSize = 11.sp
      )
    }

    // Contact Form
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text(if (isBangla) "আপনার পূর্ণ নাম" else "Your Full Name") },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("contact_name_input"),
          singleLine = true
        )

        OutlinedTextField(
          value = email,
          onValueChange = { email = it },
          label = { Text(if (isBangla) "ইমেইল অ্যাড্রেস" else "Email Address") },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("contact_email_input"),
          singleLine = true
        )

        OutlinedTextField(
          value = message,
          onValueChange = { message = it },
          label = { Text(if (isBangla) "প্রজেক্টের বিবরণ বা বার্তা" else "Project Description / Message") },
          modifier = Modifier
            .fillMaxWidth()
            .height(110.dp)
            .testTag("contact_message_input")
        )

        Button(
          onClick = {
            if (name.length < 2) {
              Toast.makeText(context, "Please enter your name", Toast.LENGTH_SHORT).show()
              return@Button
            }
            if (!email.contains("@")) {
              Toast.makeText(context, "Please enter a valid email", Toast.LENGTH_SHORT).show()
              return@Button
            }
            if (message.length < 6) {
              Toast.makeText(context, "Please describe your project", Toast.LENGTH_SHORT).show()
              return@Button
            }
            submissionNotice = "Inquiry validated for $name! Since this is a client demonstration, click Copy Email to confirm."
            Toast.makeText(context, "Form validated successfully!", Toast.LENGTH_SHORT).show()
            name = ""
            email = ""
            message = ""
          },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("contact_submit_btn")
        ) {
          Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(if (isBangla) "বার্তা পাঠান (ডেমো ভ্যালিডেশন)" else "Send Inquiry (Client Demo)")
        }

        submissionNotice?.let { notice ->
          Surface(
            color = MaterialTheme.colorScheme.secondaryContainer,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = notice,
              color = MaterialTheme.colorScheme.onSecondaryContainer,
              fontSize = 12.sp,
              modifier = Modifier.padding(10.dp)
            )
          }
        }
      }
    }
  }
}
