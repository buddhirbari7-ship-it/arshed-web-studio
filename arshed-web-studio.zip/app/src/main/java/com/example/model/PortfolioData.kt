package com.example.model

import androidx.compose.ui.graphics.Color

enum class BeadShape {
  SPHERE, OVAL, DIAMOND, CUBE, STAR, HEART, SPACER
}

data class BeadItem(
  val id: Long = System.nanoTime(),
  val shape: BeadShape,
  val color: Color,
  val sizeDp: Float = 22f
)

data class ProjectItem(
  val id: String,
  val title: String,
  val category: String,
  val description: String,
  val disclaimer: String,
  val tags: List<String>
)

data class ServiceItem(
  val title: String,
  val description: String,
  val perk: String
)

data class StudentRecord(
  val id: String,
  val name: String,
  val grade: String,
  val roll: String,
  val status: String,
  val attendance: String
)

data class TeacherRecord(
  val id: String,
  val name: String,
  val department: String,
  val role: String,
  val status: String
)

data class NoticeRecord(
  val title: String,
  val date: String,
  val tag: String,
  val content: String
)

data class NewsArticle(
  val id: Int,
  val title: String,
  val category: String,
  val time: String,
  val author: String,
  val summary: String,
  val content: String
)

// Curated Gemstone Palette
val GemstoneColors = listOf(
  Color(0xFF1565C0) to "Sapphire Blue",
  Color(0xFF2E7D32) to "Emerald Green",
  Color(0xFFC62828) to "Ruby Red",
  Color(0xFFEF6C00) to "Amber Orange",
  Color(0xFF7B1FA2) to "Amethyst Purple",
  Color(0xFF00897B) to "Teal Jade",
  Color(0xFFEC407A) to "Rose Quartz",
  Color(0xFF283593) to "Cobalt Blue",
  Color(0xFFFBC02D) to "Citrine Gold",
  Color(0xFF212121) to "Obsidian Black",
  Color(0xFFF5F5F5) to "Pearl White",
  Color(0xFFB76E79) to "Rose Gold",
  Color(0xFFD4AF37) to "Metallic Gold",
  Color(0xFFC0C0C0) to "Silver Chrome",
  Color(0xFF00ACC1) to "Turquoise"
)
