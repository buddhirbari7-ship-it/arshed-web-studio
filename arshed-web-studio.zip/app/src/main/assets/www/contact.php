<?php
/**
 * Arshed Web Studio - Optional PHP Contact Handler
 * Used when deploying to a PHP-enabled server (Apache / Nginx / cPanel).
 * Returns JSON response for AJAX form submission.
 */

header('Content-Type: application/json; charset=UTF-8');

// Configuration: Replace with real destination inbox when hosting on PHP server
$recipient_email = 'contact@arshedwebstudio.com';
$website_brand   = 'Arshed Web Studio';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Method Not Allowed. Please submit via POST.'
    ]);
    exit;
}

// Sanitize inputs
$name    = isset($_POST['name']) ? strip_tags(trim($_POST['name'])) : '';
$email   = isset($_POST['email']) ? filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL) : '';
$type    = isset($_POST['project_type']) ? strip_tags(trim($_POST['project_type'])) : 'General Inquiry';
$budget  = isset($_POST['budget']) ? strip_tags(trim($_POST['budget'])) : 'Not Specified';
$message = isset($_POST['message']) ? strip_tags(trim($_POST['message'])) : '';

// Validation
$errors = [];
if (empty($name) || strlen($name) < 2) {
    $errors[] = 'Full name is required (minimum 2 characters).';
}
if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'A valid email address is required.';
}
if (empty($message) || strlen($message) < 10) {
    $errors[] = 'Message is required (minimum 10 characters).';
}

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'errors'  => $errors,
        'message' => 'Please fix validation errors.'
    ]);
    exit;
}

// Prepare email headers and content
$subject = "[$website_brand Inquiry] $type from $name";
$email_body = "New client inquiry submitted via Arshed Web Studio portfolio:\n\n"
            . "Name: $name\n"
            . "Email: $email\n"
            . "Project Type: $type\n"
            . "Budget Range: $budget\n\n"
            . "Message:\n$message\n\n"
            . "Submitted at: " . date('Y-m-d H:i:s') . "\n";

$headers = "From: webmaster@" . ($_SERVER['SERVER_NAME'] ?? 'localhost') . "\r\n"
         . "Reply-To: $email\r\n"
         . "X-Mailer: PHP/" . phpversion();

// Attempt to send via mail() if configured
$mail_sent = false;
if (function_exists('mail') && !empty($recipient_email) && strpos($recipient_email, 'example.com') === false) {
    $mail_sent = @mail($recipient_email, $subject, $email_body, $headers);
}

echo json_encode([
    'success' => true,
    'message' => 'Thank you! Your inquiry was received.',
    'mail_sent' => $mail_sent,
    'received_data' => [
        'name' => $name,
        'email' => $email,
        'project_type' => $type,
        'budget' => $budget
    ]
]);
