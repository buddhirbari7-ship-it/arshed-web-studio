# Arshed Web Studio — Portfolio Website & Interactive Product Design Studio

**Brand Name:** Arshed Web Studio  
**Creator:** Md Arshed Alam  
**Tagline:** “Websites That Do More Than Look Good.”  
**Subtitle:** “Responsive Web Design | Interactive Prototypes | AI-Assisted Development”  
**Primary Brand Colors:** `#1565C0` (Blue) & `#2E7D32` (Emerald Green)  

---

## 1. Project Folder Structure

```text
arshed-web-studio/
├── index.html             # Main portfolio homepage & sections (Semantic HTML5)
├── contact.php            # Optional PHP backend handler for PHP servers
├── css/
│   └── styles.css         # Responsive styling, light/dark themes, animations, grid
├── js/
│   ├── app.js             # Core app logic: i18n (EN/BN), theme toggle, form validation, filter
│   ├── simulator.js       # Interactive Product Design Studio (SVG math, beads, canvas PNG export)
│   └── demos.js           # Interactive School Dashboard, News Portal demos & Case Studies
└── README.md              # Deployment guide, configuration, and verification checklist
```

---

## 2. Instructions for Running Locally

You do **not** need a build tool, Node.js, or complex compiler to run this website. It uses modern standard web standards (HTML5, CSS3, ES6+ JavaScript).

### Option A: Direct Browser Preview
Double-click `index.html` or drag it into any modern web browser (Google Chrome, Firefox, Microsoft Edge, Safari).

### Option B: Local Development Server (Recommended for export & fetch testing)
Using Python (preinstalled on most macOS/Linux systems):
```bash
# In the project directory:
python3 -m http.server 8080
```
Then open your browser at: `http://localhost:8080`

Using Node / npx (if installed):
```bash
npx serve .
```

Using VS Code:
Right-click `index.html` and choose **"Open with Live Server"**.

---

## 3. Free Hosting & Publishing Instructions

You can host this entire static portfolio completely free of charge with HTTPS:

### Option A: GitHub Pages (100% Free, Unlimited)
1. Create a free account at [github.com](https://github.com).
2. Create a new repository named `arshed-web-studio` (or `<your-username>.github.io`).
3. Upload the files from the `web/` folder (`index.html`, `css/`, `js/`, `README.md`).
4. Go to **Settings** → **Pages**.
5. Under **Branch**, select `main` (or `master`) and folder `/ (root)`. Click **Save**.
6. Within 1 minute, your portfolio will be live at `https://<your-username>.github.io/arshed-web-studio/`!

### Option B: Vercel (Fast, Global CDN)
1. Go to [vercel.com](https://vercel.com) and sign in with GitHub or email.
2. Click **"Add New Project"** → Drag and drop the project folder or select your GitHub repository.
3. Keep default settings and click **Deploy**.
4. Your site will immediately be live on a fast `.vercel.app` domain.

### Option C: Netlify (Drag & Drop in 30 seconds)
1. Go to [netlify.com](https://netlify.com) and log in.
2. Go to the **Sites** tab.
3. Drag and drop the `web/` folder into the Netlify Drop area.
4. Your site goes live instantly with an SSL certificate.

---

## 4. Configurable Values to Replace

Before publishing to clients, replace these placeholders with your real contact details:

1. **Email Address Placeholder:**
   - In `index.html`: search for `contact@arshedwebstudio.com` and replace with your real email.
   - In `contact.php`: line 11 `$recipient_email = 'your-email@domain.com';`.
   - In `js/app.js`: search for `data-email="contact@arshedwebstudio.com"`.

2. **Freelancer.com Profile URL:**
   - In `index.html`: search for `https://www.freelancer.com/u/arshedwebstudio` and replace `arshedwebstudio` with your real Freelancer username.
   - In `js/simulator.js`: summary footer link.

3. **SEO Title & Metadata:**
   - In `index.html`: adjust `<title>` or `<meta name="description">` if you want custom regional keywords.

---

## 5. Tested & Verified Features Checklist

| Feature | Status | Verification Details |
| :--- | :---: | :--- |
| **Responsive Layout** | ✅ Tested | Fluid scaling across Mobile (320px–480px), Tablet (768px), and Desktop (1024px+). |
| **Light & Dark Theme** | ✅ Tested | High-contrast tokens, persists across sessions via `localStorage`. |
| **English / Bangla Toggle** | ✅ Tested | Live bilingual dictionary toggling all titles, buttons, badges, and controls. |
| **Interactive Bead Emulator** | ✅ Tested | Dynamic SVG circular strand placement, multi-shapes, palette colors, size adjustments. |
| **Bead Reordering & Deletion**| ✅ Tested | Clockwise and counter-clockwise sequence movement, individual bead inspection. |
| **PNG Image Export** | ✅ Tested | Offscreen HTML5 Canvas generates full-resolution 800x800 PNG with instant download. |
| **Copy Design Summary** | ✅ Tested | Generates structured specification text and copies to system clipboard with toast feedback. |
| **School Dashboard Demo** | ✅ Tested | Interactive tabs (Roster, Teachers, Notices), real-time search, and demo notice publisher. |
| **News Portal Demo** | ✅ Tested | Category filtering, live headline search, breaking news ticker, full article reading view. |
| **Project Case Study Modals** | ✅ Tested | Comprehensive architectural breakdowns for all 3 showcased projects. |
| **Contact Form Client Validation** | ✅ Tested | Validates name length, email format, project type, and message with clear demo alert. |
| **Direct Contact Actions** | ✅ Tested | Working Copy Email button, Mailto link, and Freelancer profile anchor. |
| **Honest Branding Policy** | ✅ Tested | Clear disclaimers that demos use sample data and AI-assisted workflows; no fake awards. |
