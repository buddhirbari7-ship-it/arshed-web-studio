/**
 * Arshed Web Studio - Main Portfolio Application Logic
 * Manages:
 * - Theme Switcher (Light / Dark with localStorage)
 * - Language Switcher (English / বাংলা with comprehensive dictionary)
 * - Portfolio Project search & category filtering
 * - Contact form validation & demo state management
 * - Clipboard actions & toast notifications
 */

(function () {
  'use strict';

  // State
  let currentTheme = localStorage.getItem('arshed_theme') || 'light';
  let currentLang = localStorage.getItem('arshed_lang') || 'en';

  // Language Dictionary (English & Bangla)
  const I18N = {
    en: {
      brand_title: 'Arshed Web Studio',
      brand_tag: 'Freelancer Portfolio',
      nav_home: 'Home',
      nav_projects: 'Projects',
      nav_studio: 'Bead Studio',
      nav_services: 'Services',
      nav_about: 'About Me',
      nav_contact: 'Contact',
      
      hero_badge: 'Freelance Web Designer & AI-Assisted Developer',
      hero_title_1: 'Websites That Do More',
      hero_title_2: 'Than Look Good.',
      hero_subtitle: 'Responsive Web Design | Interactive Prototypes | AI-Assisted Development',
      hero_intro: 'Hi, I’m Md Arshed Alam. I build responsive web interfaces, interactive client-side simulators, and functional prototypes designed for clarity, performance, and real user engagement.',
      btn_view_projects: 'View My Projects',
      btn_try_demo: 'Try Interactive Demo',
      btn_contact_me: 'Contact Me',
      metric_live_sim: 'Live Simulator',
      metric_perf: 'Fast & Lightweight',
      metric_pure_code: 'Clean Architecture',
      
      hero_card_title: 'Interactive Bead Studio Teaser',
      hero_card_live: 'Live Canvas Engine',
      hero_card_beads: 'Beads in pattern:',
      
      projects_tag: 'Case Studies & Demos',
      projects_title: 'Featured Portfolio Projects',
      projects_subtitle: 'Practical demonstrations of custom front-end programming, responsive UI architecture, and interactive web tools.',
      filter_all: 'All Projects',
      filter_interactive: 'Interactive Prototypes',
      filter_dashboard: 'Dashboard UI',
      filter_news: 'Editorial & News',
      search_placeholder: 'Search projects...',

      studio_tag: 'Product Customizer',
      studio_title: 'Interactive Product Design Studio',
      studio_subtitle: 'A fully functional bracelet and bead customizer built with scalable vector graphics (SVG) and HTML5 Canvas image export.',
      studio_bead_count: 'Total Beads:',
      studio_est_length: 'Est. Length:',
      studio_shapes: 'Bead Shape',
      studio_colors: 'Gemstone Color',
      studio_custom_color: 'Custom Color',
      studio_presets: 'Predefined Styles',
      studio_selected_bead: 'Selected Bead Settings',
      studio_size: 'Bead Size',
      studio_string_style: 'String / Cord Style',
      studio_reorder: 'Reorder Bead',
      btn_add_bead: 'Add Bead (+)',
      btn_remove_bead: 'Remove Bead (✕)',
      btn_random_design: 'Random Design',
      btn_reset_design: 'Reset Design',
      btn_clear_design: 'Clear All',
      btn_download_png: 'Download PNG Image',
      btn_copy_summary: 'Copy Design Summary',

      services_tag: 'Capabilities',
      services_title: 'Services I Offer',
      services_subtitle: 'Clear, modern web design and front-end development tailored for businesses and individual clients.',

      about_tag: 'Meet The Creator',
      about_title: 'About Md Arshed Alam',
      about_subtitle: 'Dedicated freelance web designer and front-end developer based at Arshed Web Studio.',
      about_p1: 'I am a freelance web designer and front-end developer passionate about creating responsive, interactive, and cleanly structured web experiences.',
      about_p2: 'In my daily development, I thoughtfully embrace modern AI-assisted workflows alongside core HTML5, CSS3, and JavaScript standards. This allows me to prototype complex interactive concepts rapidly, write cleaner code, and deliver polished web solutions on time without cutting corners on design principles.',
      about_honesty: 'Every project showcased in this portfolio represents real working code created to demonstrate functional skills for clients on Freelancer.com.',

      contact_tag: 'Get In Touch',
      contact_title: 'Let’s Build Something Great',
      contact_subtitle: 'Have a project in mind or want to discuss a custom design simulator? Reach out today.',
      contact_form_name: 'Your Full Name',
      contact_form_email: 'Email Address',
      contact_form_type: 'Project Type',
      contact_form_budget: 'Budget Range',
      contact_form_msg: 'Project Description / Message',
      btn_send_msg: 'Send Inquiry (Demo)',
      contact_demo_notice: 'Notice: This contact form runs client-side validation. To send a direct message, use the Copy Email button or click to connect on Freelancer.com.',
      btn_copy_email: 'Copy Email Address',
      btn_view_freelancer: 'View Freelancer Profile',

      footer_crafted: 'Crafted with care by Md Arshed Alam',
      footer_rights: 'All rights reserved.'
    },
    bn: {
      brand_title: 'আরশেদ ওয়েব স্টুডিও',
      brand_tag: 'ফ্রিল্যান্সার পোর্টফোলিও',
      nav_home: 'হোম',
      nav_projects: 'প্রজেক্টস',
      nav_studio: 'বিড স্টুডিও',
      nav_services: 'সার্ভিসসমূহ',
      nav_about: 'আমার সম্পর্কে',
      nav_contact: 'যোগাযোগ',

      hero_badge: 'ফ্রিল্যান্স ওয়েব ডিজাইনার ও এআই-সহযোগী ডেভেলপার',
      hero_title_1: 'ওয়েবসাইট যা শুধু দেখতে সুন্দর নয়,',
      hero_title_2: 'বরং কার্যকরী ও ইন্টারেক্টিভ।',
      hero_subtitle: 'রেসপনসিভ ওয়েব ডিজাইন | ইন্টারেক্টিভ প্রোটোটাইপ | এআই-সহায়তা ভিত্তিক ডেভেলপমেন্ট',
      hero_intro: 'আমি মো. আরশেদ আলম। আধুনিক ওয়েব প্রযুক্তি এবং উন্নত এআই-সহায়তায় আমি রেসপনসিভ ইন্টারফেস, ইন্টারেক্টিভ ডিজাইন সিমুলেটর ও পরিষ্কার কোডযুক্ত ড্যাশবোর্ড তৈরি করি।',
      btn_view_projects: 'প্রজেক্টগুলো দেখুন',
      btn_try_demo: 'ইন্টারেক্টিভ ডেমো চালান',
      btn_contact_me: 'যোগাযোগ করুন',
      metric_live_sim: 'লাইভ সিমুলেটর',
      metric_perf: 'দ্রুত ও হালকা',
      metric_pure_code: 'পরিষ্কার আর্কিটেকচার',

      hero_card_title: 'ইন্টারেক্টিভ বিড স্টুডিও প্রিভিউ',
      hero_card_live: 'লাইভ ক্যানভাস ইঞ্জিন',
      hero_card_beads: 'ডিজাইনে বিড সংখ্যা:',

      projects_tag: 'কেস স্টাডি ও ডেমো',
      projects_title: 'নির্বাচিত পোর্টফোলিও প্রজেক্ট',
      projects_subtitle: 'ব্যবহারিক ফ্রন্ট-এন্ড কোডিং, রেসপনসিভ ইউআই এবং কার্যকরী ওয়েব টুলের বাস্তব উদাহরণ।',
      filter_all: 'সকল প্রজেক্ট',
      filter_interactive: 'ইন্টারেক্টিভ প্রোটোটাইপ',
      filter_dashboard: 'ড্যাশবোর্ড ইউআই',
      filter_news: 'সংবাদ ও প্রকাশনা',
      search_placeholder: 'প্রজেক্ট খুঁজুন...',

      studio_tag: 'প্রোডাক্ট কাস্টমাইজার',
      studio_title: 'ইন্টারেক্টিভ প্রোডাক্ট ডিজাইন স্টুডিও',
      studio_subtitle: 'ভেক্টর গ্রাফিক্স (SVG) এবং ক্যানভাস এক্সপোর্ট সহ বাস্তবধর্মী ব্রেসলেট ও বিড ডিজাইন সিমুলেটর।',
      studio_bead_count: 'মোট বিড:',
      studio_est_length: 'আনুমানিক দৈর্ঘ্য:',
      studio_shapes: 'বিডের আকৃতি',
      studio_colors: 'রঙ নির্বাচন',
      studio_custom_color: 'কাস্টম রঙ',
      studio_presets: 'পূর্বনির্ধারিত স্টাইল',
      studio_selected_bead: 'নির্বাচিত বিড সেটিংস',
      studio_size: 'বিড সাইজ',
      studio_string_style: 'সুতো / চেইনের ধরন',
      studio_reorder: 'স্থান পরিবর্তন',
      btn_add_bead: 'বিড যুক্ত করুন (+)',
      btn_remove_bead: 'বিড মুছুন (✕)',
      btn_random_design: 'র‍্যান্ডম ডিজাইন',
      btn_reset_design: 'রিসেট করুন',
      btn_clear_design: 'সব মুছুন',
      btn_download_png: 'PNG ইমেজ ডাউনলোড',
      btn_copy_summary: 'ডিজাইন সামারি কপি',

      services_tag: 'দক্ষতা ও সেবা',
      services_title: 'আমার প্রদেয় সার্ভিসসমূহ',
      services_subtitle: 'ব্যবসা ও ক্লায়েন্টদের জন্য মানসম্মত, আধুনিক ও রেসপনসিভ ওয়েব সল্যুশন।',

      about_tag: 'পরিচয়',
      about_title: 'মো. আরশেদ আলম সম্পর্কে',
      about_subtitle: 'আরশেদ ওয়েব স্টুডিওর প্রতিষ্ঠাতা এবং ফ্রিল্যান্স ফ্রন্ট-এন্ড ডেভেলপার।',
      about_p1: 'আমি একজন ফ্রিল্যান্স ওয়েব ডিজাইনার এবং ফ্রন্ট-এন্ড ডেভেলপার। আমি রেসপনসিভ, দ্রুতগতির ও দৃষ্টি-নন্দন ওয়েব অভিজ্ঞতা তৈরি করতে ভালোবাসি।',
      about_p2: 'আমার দৈনন্দিন ডেভেলপমেন্ট কাজে আমি HTML5, CSS3 ও আধুনিক জাভাস্ক্রিপ্টের পাশাপাশি নির্ভরযোগ্য এআই-সহায়ক টুল ব্যবহার করি। এর ফলে জটিল ইন্টারফেস দ্রুত প্রোটোটাইপ করা এবং সময়মতো মানসম্মত ডেলিভারি দেওয়া সম্ভব হয়।',
      about_honesty: 'এই পোর্টফোলিওর প্রতিটি প্রজেক্ট ক্লায়েন্টদের জন্য আমার বাস্তব কাজের সক্ষমতা প্রদর্শনের উদ্দেশ্যে নিখুঁতভাবে তৈরি করা হয়েছে।',

      contact_tag: 'যোগাযোগ',
      contact_title: 'আসুন একসাথে প্রজেক্ট শুরু করি',
      contact_subtitle: 'আপনার কোনো নতুন প্রজেক্ট বা কাস্টম ডিজাইন সিমুলেটর প্রয়োজন হলে বার্তা পাঠান।',
      contact_form_name: 'আপনার নাম',
      contact_form_email: 'ইমেইল অ্যাড্রেস',
      contact_form_type: 'প্রজেক্টের ধরন',
      contact_form_budget: 'বাজেট সীমা',
      contact_form_msg: 'প্রজেক্টের বিবরণ বা বার্তা',
      btn_send_msg: 'বার্তা পাঠান (ডেমো)',
      contact_demo_notice: 'সতর্কতা: এই ফর্মটি ক্লায়েন্ট-সাইড ভ্যালিডেশন ডেমো হিসেবে পরিচালিত। সরাসরি মেসেজ দিতে কপি ইমেইল বা ফ্রিল্যান্সার প্রোফাইল লিংক ব্যবহার করুন।',
      btn_copy_email: 'ইমেইল কপি করুন',
      btn_view_freelancer: 'ফ্রিল্যান্সার প্রোফাইল দেখুন',

      footer_crafted: 'মো. আরশেদ আলম কর্তৃক সযত্নে নির্মিত',
      footer_rights: 'সর্বস্বত্ব সংরক্ষিত।'
    }
  };

  // Initialize
  function init() {
    applyTheme(currentTheme);
    applyLanguage(currentLang);

    setupThemeToggle();
    setupLanguageToggle();
    setupMobileMenu();
    setupProjectFiltering();
    setupContactForm();
    setupQuickActions();
    setupActiveNavScroll();
  }

  // Theme Management
  function applyTheme(theme) {
    currentTheme = theme;
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('arshed_theme', theme);

    const themeIcon = document.getElementById('themeToggleIcon');
    if (themeIcon) {
      if (theme === 'dark') {
        // Show Sun icon
        themeIcon.innerHTML = `<path d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" stroke="currentColor" stroke-width="2" stroke-linecap="round" fill="none"/>`;
      } else {
        // Show Moon icon
        themeIcon.innerHTML = `<path d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" stroke="currentColor" stroke-width="2" stroke-linecap="round" fill="none"/>`;
      }
    }
  }

  function setupThemeToggle() {
    const btn = document.getElementById('themeToggleBtn');
    if (btn) {
      btn.addEventListener('click', () => {
        applyTheme(currentTheme === 'dark' ? 'light' : 'dark');
      });
    }
  }

  // Language Management
  function applyLanguage(lang) {
    currentLang = lang;
    localStorage.setItem('arshed_lang', lang);

    if (lang === 'bn') {
      document.body.classList.add('lang-bn');
    } else {
      document.body.classList.remove('lang-bn');
    }

    const dict = I18N[lang] || I18N.en;

    // Replace all elements with data-i18n
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (dict[key]) {
        el.textContent = dict[key];
      }
    });

    // Replace placeholders with data-i18n-ph
    document.querySelectorAll('[data-i18n-ph]').forEach(el => {
      const key = el.getAttribute('data-i18n-ph');
      if (dict[key]) {
        el.setAttribute('placeholder', dict[key]);
      }
    });

    // Update language button text
    const langBtns = document.querySelectorAll('.lang-toggle-btn');
    langBtns.forEach(btn => {
      btn.textContent = lang === 'en' ? 'বাংলা' : 'EN';
    });
  }

  function setupLanguageToggle() {
    document.querySelectorAll('.lang-toggle-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        applyLanguage(currentLang === 'en' ? 'bn' : 'en');
        showToast(currentLang === 'bn' ? 'ভাষা বাংলায় পরিবর্তিত হয়েছে' : 'Language switched to English');
      });
    });
  }

  // Mobile Navigation Menu
  function setupMobileMenu() {
    const mobileBtn = document.getElementById('mobileMenuBtn');
    const nav = document.getElementById('mainNav');

    if (mobileBtn && nav) {
      mobileBtn.addEventListener('click', () => {
        nav.classList.toggle('mobile-open');
        const isOpen = nav.classList.contains('mobile-open');
        mobileBtn.setAttribute('aria-expanded', isOpen);
      });

      // Close menu when clicking link
      nav.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', () => {
          nav.classList.remove('mobile-open');
        });
      });
    }
  }

  // Active Navigation link on scroll
  function setupActiveNavScroll() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-link');

    window.addEventListener('scroll', () => {
      let currentId = '';
      const scrollY = window.pageYOffset;

      sections.forEach(sec => {
        const top = sec.offsetTop - 120;
        const height = sec.offsetHeight;
        if (scrollY >= top && scrollY < top + height) {
          currentId = sec.getAttribute('id');
        }
      });

      navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${currentId}`) {
          link.classList.add('active');
        }
      });
    });
  }

  // Project Search and Category Filter
  function setupProjectFiltering() {
    const pills = document.querySelectorAll('.filter-pill');
    const searchInput = document.getElementById('projectSearchInput');
    const cards = document.querySelectorAll('.project-card');

    let activeFilter = 'all';
    let searchQuery = '';

    function filterCards() {
      let visibleCount = 0;
      cards.forEach(card => {
        const cat = card.getAttribute('data-category');
        const title = card.querySelector('.project-name').textContent.toLowerCase();
        const desc = card.querySelector('.project-desc').textContent.toLowerCase();

        const matchesFilter = activeFilter === 'all' || cat === activeFilter;
        const matchesSearch = !searchQuery || title.includes(searchQuery) || desc.includes(searchQuery);

        if (matchesFilter && matchesSearch) {
          card.style.display = 'flex';
          visibleCount++;
        } else {
          card.style.display = 'none';
        }
      });

      const emptyNotice = document.getElementById('projectsEmptyNotice');
      if (emptyNotice) {
        emptyNotice.style.display = visibleCount === 0 ? 'block' : 'none';
      }
    }

    pills.forEach(pill => {
      pill.addEventListener('click', () => {
        pills.forEach(p => p.classList.remove('active'));
        pill.classList.add('active');
        activeFilter = pill.getAttribute('data-filter');
        filterCards();
      });
    });

    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        searchQuery = e.target.value.trim().toLowerCase();
        filterCards();
      });
    }
  }

  // Contact Form Validation & State
  function setupContactForm() {
    const form = document.getElementById('portfolioContactForm');
    if (!form) return;

    form.addEventListener('submit', (e) => {
      e.preventDefault();

      let isValid = true;
      const name = document.getElementById('contactName');
      const email = document.getElementById('contactEmail');
      const type = document.getElementById('contactType');
      const budget = document.getElementById('contactBudget');
      const msg = document.getElementById('contactMessage');
      const alertBox = document.getElementById('contactFormAlert');

      // Clear previous invalid states
      [name, email, type, msg].forEach(field => {
        if (field) {
          field.classList.remove('is-invalid');
          const err = field.parentElement.querySelector('.field-error-msg');
          if (err) err.classList.remove('visible');
        }
      });

      // Name validation
      if (!name.value.trim() || name.value.trim().length < 2) {
        markInvalid(name, 'Please provide your full name (minimum 2 characters).');
        isValid = false;
      }

      // Email validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!email.value.trim() || !emailRegex.test(email.value.trim())) {
        markInvalid(email, 'Please enter a valid email address.');
        isValid = false;
      }

      // Project Type
      if (!type.value) {
        markInvalid(type, 'Please select your project type.');
        isValid = false;
      }

      // Message validation
      if (!msg.value.trim() || msg.value.trim().length < 10) {
        markInvalid(msg, 'Please describe your project (minimum 10 characters).');
        isValid = false;
      }

      if (!isValid) {
        if (alertBox) {
          alertBox.className = 'form-status-alert error';
          alertBox.textContent = 'Please review the highlighted errors above.';
        }
        return;
      }

      // Show submitting state
      const submitBtn = form.querySelector('button[type="submit"]');
      const originalText = submitBtn.textContent;
      submitBtn.disabled = true;
      submitBtn.textContent = 'Validating & Simulating...';

      setTimeout(() => {
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;

        if (alertBox) {
          alertBox.className = 'form-status-alert success';
          alertBox.innerHTML = `
            <strong>Inquiry Demo Validated!</strong><br>
            Thank you, <em>${escapeHtml(name.value.trim())}</em>. All form fields passed validation. Since this is client-side hosting, please click "Copy Email" or reach out on Freelancer.com to confirm your brief!
          `;
        }

        showToast('Contact form validated successfully!');
        form.reset();
      }, 700);
    });

    function markInvalid(el, msgText) {
      if (!el) return;
      el.classList.add('is-invalid');
      const err = el.parentElement.querySelector('.field-error-msg');
      if (err) {
        err.textContent = msgText;
        err.classList.add('visible');
      }
    }
  }

  // Quick Action Buttons (Copy Email, Freelancer Profile)
  function setupQuickActions() {
    const copyEmailBtns = document.querySelectorAll('[data-action="copy-email"]');
    copyEmailBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const email = btn.getAttribute('data-email') || 'contact@arshedwebstudio.com';
        copyToClipboard(email, `Email copied: ${email}`);
      });
    });

    // Back to top button
    const backToTopBtn = document.getElementById('backToTopBtn');
    if (backToTopBtn) {
      backToTopBtn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    }
  }

  function copyToClipboard(text, msg) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(() => {
        showToast(msg);
      }).catch(() => {
        fallbackCopy(text, msg);
      });
    } else {
      fallbackCopy(text, msg);
    }
  }

  function fallbackCopy(text, msg) {
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    try {
      document.execCommand('copy');
      showToast(msg);
    } catch (e) {
      prompt('Copy Email Address:', text);
    }
    document.body.removeChild(ta);
  }

  function showToast(msg) {
    const toast = document.getElementById('globalToast');
    if (!toast) return;
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => {
      toast.classList.remove('show');
    }, 2800);
  }

  function escapeHtml(str) {
    return str.replace(/[&<>'"]/g, tag => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      "'": '&#39;',
      '"': '&quot;'
    }[tag] || tag));
  }

  // Run on start
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
