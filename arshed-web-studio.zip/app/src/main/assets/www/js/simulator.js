/**
 * Arshed Web Studio - Interactive Product Design Studio (Bracelet & Bead Emulator)
 * Provides full dynamic SVG rendering, customizable bead shapes, colors, sizing,
 * reordering, string styling, presets, PNG export, and clipboard summary copy.
 */

(function () {
  'use strict';

  // State
  const state = {
    beads: [],
    selectedIndex: 0,
    currentShape: 'sphere',
    currentColor: '#1565C0',
    stringStyle: 'elastic',
    beadSize: 22, // default radius/size
    isRotating: false,
    rotationAngle: 0,
    animationFrameId: null
  };

  // Color Palette Definitions
  const COLOR_PALETTE = [
    { name: 'Sapphire Blue', hex: '#1565C0' },
    { name: 'Emerald Green', hex: '#2E7D32' },
    { name: 'Ruby Red', hex: '#C62828' },
    { name: 'Amber Orange', hex: '#EF6C00' },
    { name: 'Amethyst Purple', hex: '#7B1FA2' },
    { name: 'Teal Jade', hex: '#00897B' },
    { name: 'Rose Quartz', hex: '#EC407A' },
    { name: 'Cobalt Blue', hex: '#283593' },
    { name: 'Citrine Gold', hex: '#FBC02D' },
    { name: 'Obsidian Black', hex: '#212121' },
    { name: 'Pearl White', hex: '#F5F5F5' },
    { name: 'Rose Gold', hex: '#B76E79' },
    { name: 'Metallic Gold', hex: '#D4AF37' },
    { name: 'Silver Chrome', hex: '#C0C0C0' },
    { name: 'Turquoise', hex: '#00ACC1' }
  ];

  // Predefined Design Presets
  const PRESETS = {
    azure: {
      name: 'Azure Ocean',
      string: 'silver',
      beads: [
        { shape: 'sphere', color: '#1565C0', size: 22 },
        { shape: 'spacer', color: '#C0C0C0', size: 16 },
        { shape: 'oval', color: '#00ACC1', size: 24 },
        { shape: 'spacer', color: '#C0C0C0', size: 16 },
        { shape: 'sphere', color: '#F5F5F5', size: 20 },
        { shape: 'diamond', color: '#283593', size: 22 },
        { shape: 'sphere', color: '#F5F5F5', size: 20 },
        { shape: 'spacer', color: '#C0C0C0', size: 16 },
        { shape: 'oval', color: '#00ACC1', size: 24 },
        { shape: 'spacer', color: '#C0C0C0', size: 16 },
        { shape: 'sphere', color: '#1565C0', size: 22 },
        { shape: 'star', color: '#D4AF37', size: 24 },
        { shape: 'sphere', color: '#1565C0', size: 22 },
        { shape: 'spacer', color: '#C0C0C0', size: 16 }
      ]
    },
    emerald: {
      name: 'Emerald Forest',
      string: 'gold',
      beads: [
        { shape: 'sphere', color: '#2E7D32', size: 24 },
        { shape: 'spacer', color: '#D4AF37', size: 16 },
        { shape: 'facet', color: '#00897B', size: 22 },
        { shape: 'sphere', color: '#F5F5F5', size: 18 },
        { shape: 'cube', color: '#2E7D32', size: 22 },
        { shape: 'spacer', color: '#D4AF37', size: 16 },
        { shape: 'sphere', color: '#FBC02D', size: 20 },
        { shape: 'facet', color: '#00897B', size: 22 },
        { shape: 'spacer', color: '#D4AF37', size: 16 },
        { shape: 'sphere', color: '#2E7D32', size: 24 },
        { shape: 'heart', color: '#D4AF37', size: 24 },
        { shape: 'spacer', color: '#D4AF37', size: 16 }
      ]
    },
    sunset: {
      name: 'Sunset Coral',
      string: 'braided',
      beads: [
        { shape: 'oval', color: '#EF6C00', size: 24 },
        { shape: 'spacer', color: '#B76E79', size: 16 },
        { shape: 'sphere', color: '#C62828', size: 22 },
        { shape: 'heart', color: '#EC407A', size: 24 },
        { shape: 'sphere', color: '#FBC02D', size: 20 },
        { shape: 'spacer', color: '#B76E79', size: 16 },
        { shape: 'sphere', color: '#EF6C00', size: 22 },
        { shape: 'facet', color: '#EC407A', size: 22 },
        { shape: 'spacer', color: '#B76E79', size: 16 },
        { shape: 'sphere', color: '#C62828', size: 22 },
        { shape: 'oval', color: '#EF6C00', size: 24 },
        { shape: 'spacer', color: '#B76E79', size: 16 }
      ]
    },
    monochrome: {
      name: 'Monochrome Minimal',
      string: 'elastic',
      beads: [
        { shape: 'sphere', color: '#212121', size: 24 },
        { shape: 'spacer', color: '#C0C0C0', size: 16 },
        { shape: 'sphere', color: '#F5F5F5', size: 22 },
        { shape: 'cube', color: '#212121', size: 22 },
        { shape: 'spacer', color: '#C0C0C0', size: 16 },
        { shape: 'diamond', color: '#C0C0C0', size: 22 },
        { shape: 'sphere', color: '#F5F5F5', size: 22 },
        { shape: 'spacer', color: '#C0C0C0', size: 16 },
        { shape: 'sphere', color: '#212121', size: 24 },
        { shape: 'spacer', color: '#C0C0C0', size: 16 },
        { shape: 'cube', color: '#F5F5F5', size: 22 },
        { shape: 'spacer', color: '#C0C0C0', size: 16 }
      ]
    },
    royal: {
      name: 'Royal Amethyst',
      string: 'gold',
      beads: [
        { shape: 'facet', color: '#7B1FA2', size: 24 },
        { shape: 'spacer', color: '#D4AF37', size: 16 },
        { shape: 'sphere', color: '#1565C0', size: 22 },
        { shape: 'star', color: '#D4AF37', size: 24 },
        { shape: 'sphere', color: '#7B1FA2', size: 22 },
        { shape: 'spacer', color: '#D4AF37', size: 16 },
        { shape: 'sphere', color: '#F5F5F5', size: 20 },
        { shape: 'facet', color: '#7B1FA2', size: 24 },
        { shape: 'spacer', color: '#D4AF37', size: 16 },
        { shape: 'sphere', color: '#1565C0', size: 22 },
        { shape: 'spacer', color: '#D4AF37', size: 16 }
      ]
    },
    rainbow: {
      name: 'Rainbow Fusion',
      string: 'elastic',
      beads: [
        { shape: 'sphere', color: '#C62828', size: 22 },
        { shape: 'sphere', color: '#EF6C00', size: 22 },
        { shape: 'sphere', color: '#FBC02D', size: 22 },
        { shape: 'sphere', color: '#2E7D32', size: 22 },
        { shape: 'sphere', color: '#00ACC1', size: 22 },
        { shape: 'sphere', color: '#1565C0', size: 22 },
        { shape: 'sphere', color: '#7B1FA2', size: 22 },
        { shape: 'sphere', color: '#EC407A', size: 22 },
        { shape: 'spacer', color: '#D4AF37', size: 16 },
        { shape: 'star', color: '#D4AF37', size: 24 },
        { shape: 'spacer', color: '#D4AF37', size: 16 }
      ]
    }
  };

  // DOM Elements
  let svgEl, heroSvgEl;
  let beadCountEl, heroCountEl, estLengthEl;
  let selectedIndexLabel, selectedBeadPreview, selectedSizeInput, selectedSizeVal;
  let stringSelectEl;

  // Initialize
  function init() {
    svgEl = document.getElementById('beadDesignSvg');
    heroSvgEl = document.getElementById('heroDesignSvg');
    beadCountEl = document.getElementById('studioBeadCount');
    heroCountEl = document.getElementById('heroBeadCount');
    estLengthEl = document.getElementById('studioEstLength');
    selectedIndexLabel = document.getElementById('selectedBeadIndexLabel');
    selectedBeadPreview = document.getElementById('selectedBeadPreviewCircle');
    selectedSizeInput = document.getElementById('selectedBeadSizeInput');
    selectedSizeVal = document.getElementById('selectedBeadSizeVal');
    stringSelectEl = document.getElementById('studioStringStyle');

    // Load initial preset (Azure Ocean)
    loadPreset('azure');

    // Setup Event Listeners
    setupControls();

    // Render initial
    renderStudio();
    renderHeroPreview();
  }

  // Load a preset
  function loadPreset(key) {
    if (!PRESETS[key]) return;
    const preset = PRESETS[key];
    state.beads = JSON.parse(JSON.stringify(preset.beads));
    state.stringStyle = preset.string || 'elastic';
    state.selectedIndex = 0;
    if (stringSelectEl) stringSelectEl.value = state.stringStyle;
    renderStudio();
    renderHeroPreview();
    showToast(`Loaded preset: ${preset.name}`);
  }

  // Render Studio SVG
  function renderStudio() {
    if (!svgEl) return;
    const count = state.beads.length;

    // Update Counts
    if (beadCountEl) beadCountEl.textContent = count;
    if (heroCountEl) heroCountEl.textContent = count;

    // Estimate length in cm (approx ~1.2cm per bead average)
    if (estLengthEl) {
      const avgMm = state.beads.reduce((acc, b) => acc + (b.size || 20), 0) / (count || 1);
      const estCm = ((count * avgMm * 0.9) / 10).toFixed(1);
      estLengthEl.textContent = `${estCm} cm`;
    }

    // Empty state handling
    const emptyState = document.getElementById('studioEmptyState');
    if (count === 0) {
      svgEl.innerHTML = '';
      if (emptyState) emptyState.classList.add('active');
      updateInspector();
      return;
    } else {
      if (emptyState) emptyState.classList.remove('active');
    }

    if (state.selectedIndex >= count) {
      state.selectedIndex = Math.max(0, count - 1);
    }

    // Canvas Dimensions
    const size = 460;
    const cx = size / 2;
    const cy = size / 2;
    const radius = 160;

    // Build SVG Content
    let defs = `
      <defs>
        <radialGradient id="cordShadow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="#000000" stop-opacity="0.3"/>
          <stop offset="100%" stop-color="#000000" stop-opacity="0"/>
        </radialGradient>
        <filter id="softGlow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="3" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
        <filter id="dropShadow" x="-30%" y="-30%" width="160%" height="160%">
          <feDropShadow dx="0" dy="5" stdDeviation="4" flood-color="rgba(0,0,0,0.25)"/>
        </filter>
    `;

    // Gradients for each bead
    state.beads.forEach((bead, i) => {
      const gradId = `beadGrad_${i}`;
      defs += `
        <radialGradient id="${gradId}" cx="35%" cy="30%" r="65%">
          <stop offset="0%" stop-color="#FFFFFF" stop-opacity="0.85"/>
          <stop offset="25%" stop-color="${bead.color}" stop-opacity="0.95"/>
          <stop offset="85%" stop-color="${adjustBrightness(bead.color, -35)}"/>
          <stop offset="100%" stop-color="${adjustBrightness(bead.color, -60)}"/>
        </radialGradient>
      `;
    });
    defs += `</defs>`;

    // String Strand styling
    let stringStroke = '#CBD5E1';
    let stringWidth = 4;
    let stringDash = 'none';

    if (state.stringStyle === 'braided') {
      stringStroke = '#8D6E63';
      stringWidth = 5;
      stringDash = '3,2';
    } else if (state.stringStyle === 'gold') {
      stringStroke = '#D4AF37';
      stringWidth = 4.5;
    } else if (state.stringStyle === 'silver') {
      stringStroke = '#B0BEC5';
      stringWidth = 4.5;
    } else if (state.stringStyle === 'filament') {
      stringStroke = '#E0F2FE';
      stringWidth = 2.5;
    }

    const stringPath = `<circle cx="${cx}" cy="${cy}" r="${radius}" fill="none" stroke="${stringStroke}" stroke-width="${stringWidth}" stroke-dasharray="${stringDash}" />`;

    // Group with rotation angle
    let beadsGroup = `<g transform="rotate(${state.rotationAngle} ${cx} ${cy})">`;

    // Render Beads around circle
    state.beads.forEach((bead, i) => {
      const angle = (i / count) * 2 * Math.PI - Math.PI / 2;
      const bx = cx + radius * Math.cos(angle);
      const by = cy + radius * Math.sin(angle);
      const isSelected = i === state.selectedIndex;
      const gradId = `beadGrad_${i}`;
      const beadSize = (bead.size || 22) * 0.85;

      beadsGroup += `<g class="svg-bead-element ${isSelected ? 'selected' : ''}" data-index="${i}" transform="translate(${bx}, ${by})">`;

      // Selection ring
      if (isSelected) {
        beadsGroup += `<circle cx="0" cy="0" r="${beadSize + 6}" fill="none" stroke="#FFD700" stroke-width="2.5" stroke-dasharray="4,3" />`;
      }

      // Shape rendering
      switch (bead.shape) {
        case 'oval':
          beadsGroup += `<ellipse cx="0" cy="0" rx="${beadSize * 1.2}" ry="${beadSize * 0.85}" fill="url(#${gradId})" filter="url(#dropShadow)" />`;
          break;
        case 'facet':
        case 'diamond':
          beadsGroup += `<polygon points="0,${-beadSize * 1.2} ${beadSize * 1.1},0 0,${beadSize * 1.2} ${-beadSize * 1.1},0" fill="url(#${gradId})" filter="url(#dropShadow)" />
          <polygon points="0,${-beadSize * 0.6} ${beadSize * 0.6},0 0,${beadSize * 0.6} ${-beadSize * 0.6},0" fill="rgba(255,255,255,0.3)" />`;
          break;
        case 'cube':
          beadsGroup += `<rect x="${-beadSize * 0.85}" y="${-beadSize * 0.85}" width="${beadSize * 1.7}" height="${beadSize * 1.7}" rx="4" fill="url(#${gradId})" filter="url(#dropShadow)" />`;
          break;
        case 'star':
          beadsGroup += `<polygon points="${getStarPoints(0, 0, 5, beadSize * 1.2, beadSize * 0.55)}" fill="url(#${gradId})" filter="url(#dropShadow)" />`;
          break;
        case 'heart':
          beadsGroup += `<path d="M 0,${beadSize * 0.8} C ${-beadSize * 1.4},0 ${-beadSize * 1.4},${-beadSize * 0.9} 0,${-beadSize * 0.4} C ${beadSize * 1.4},${-beadSize * 0.9} ${beadSize * 1.4},0 0,${beadSize * 0.8} Z" fill="url(#${gradId})" filter="url(#dropShadow)" />`;
          break;
        case 'spacer':
          beadsGroup += `<circle cx="0" cy="0" r="${beadSize * 0.65}" fill="url(#${gradId})" filter="url(#dropShadow)" />
          <circle cx="0" cy="0" r="${beadSize * 0.25}" fill="#1E293B" />`;
          break;
        case 'sphere':
        default:
          beadsGroup += `<circle cx="0" cy="0" r="${beadSize}" fill="url(#${gradId})" filter="url(#dropShadow)" />
          <circle cx="${-beadSize * 0.3}" cy="${-beadSize * 0.35}" r="${beadSize * 0.25}" fill="#FFFFFF" opacity="0.6" />`;
          break;
      }

      // Index label for clarity
      beadsGroup += `<text x="0" y="3.5" font-size="9" font-weight="700" text-anchor="middle" fill="#FFFFFF" opacity="0.85" pointer-events="none">${i + 1}</text>`;

      beadsGroup += `</g>`;
    });

    beadsGroup += `</g>`;

    svgEl.innerHTML = `${defs}${stringPath}${beadsGroup}`;

    // Attach click events on beads
    svgEl.querySelectorAll('.svg-bead-element').forEach(el => {
      el.addEventListener('click', (e) => {
        const idx = parseInt(el.getAttribute('data-index'), 10);
        selectBead(idx);
      });
    });

    updateInspector();
  }

  // Render mini preview in Hero section
  function renderHeroPreview() {
    if (!heroSvgEl) return;
    const count = state.beads.length;
    if (count === 0) {
      heroSvgEl.innerHTML = '';
      return;
    }

    const size = 200;
    const cx = size / 2;
    const cy = size / 2;
    const radius = 68;

    let defs = `<defs>`;
    state.beads.forEach((bead, i) => {
      defs += `
        <radialGradient id="heroGrad_${i}" cx="35%" cy="30%" r="65%">
          <stop offset="0%" stop-color="#FFFFFF" stop-opacity="0.85"/>
          <stop offset="30%" stop-color="${bead.color}"/>
          <stop offset="100%" stop-color="${adjustBrightness(bead.color, -50)}"/>
        </radialGradient>
      `;
    });
    defs += `</defs>`;

    const stringPath = `<circle cx="${cx}" cy="${cy}" r="${radius}" fill="none" stroke="#94A3B8" stroke-width="2" stroke-dasharray="2,2" />`;

    let beadsGroup = `<g transform="rotate(${state.rotationAngle} ${cx} ${cy})">`;
    state.beads.forEach((bead, i) => {
      const angle = (i / count) * 2 * Math.PI - Math.PI / 2;
      const bx = cx + radius * Math.cos(angle);
      const by = cy + radius * Math.sin(angle);
      const beadSize = Math.max(5, (bead.size || 20) * 0.38);

      beadsGroup += `<circle cx="${bx}" cy="${by}" r="${beadSize}" fill="url(#heroGrad_${i})" />`;
    });
    beadsGroup += `</g>`;

    heroSvgEl.innerHTML = `${defs}${stringPath}${beadsGroup}`;
  }

  // Update Inspector Panel
  function updateInspector() {
    const bead = state.beads[state.selectedIndex];
    if (!bead) {
      if (selectedIndexLabel) selectedIndexLabel.textContent = 'None';
      if (selectedBeadPreview) selectedBeadPreview.style.backgroundColor = 'transparent';
      return;
    }

    if (selectedIndexLabel) selectedIndexLabel.textContent = `#${state.selectedIndex + 1} (${capitalize(bead.shape)})`;
    if (selectedBeadPreview) selectedBeadPreview.style.backgroundColor = bead.color;
    if (selectedSizeInput) selectedSizeInput.value = bead.size || 22;
    if (selectedSizeVal) selectedSizeVal.textContent = `${bead.size || 22}px`;
  }

  // Select bead by index
  function selectBead(idx) {
    if (idx < 0 || idx >= state.beads.length) return;
    state.selectedIndex = idx;
    renderStudio();
  }

  // Setup UI controls
  function setupControls() {
    // Shape picker buttons
    document.querySelectorAll('.shape-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.shape-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        state.currentShape = btn.getAttribute('data-shape');

        // Update selected bead's shape immediately
        if (state.beads[state.selectedIndex]) {
          state.beads[state.selectedIndex].shape = state.currentShape;
          renderStudio();
          renderHeroPreview();
        }
      });
    });

    // Color Swatch buttons
    document.querySelectorAll('.color-swatch-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.color-swatch-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        state.currentColor = btn.getAttribute('data-color');

        // Update selected bead's color immediately
        if (state.beads[state.selectedIndex]) {
          state.beads[state.selectedIndex].color = state.currentColor;
          renderStudio();
          renderHeroPreview();
        }
      });
    });

    // Custom color input
    const customColorInput = document.getElementById('customBeadColorInput');
    if (customColorInput) {
      customColorInput.addEventListener('input', (e) => {
        state.currentColor = e.target.value;
        if (state.beads[state.selectedIndex]) {
          state.beads[state.selectedIndex].color = state.currentColor;
          renderStudio();
          renderHeroPreview();
        }
      });
    }

    // Size Slider
    if (selectedSizeInput) {
      selectedSizeInput.addEventListener('input', (e) => {
        const val = parseInt(e.target.value, 10);
        if (selectedSizeVal) selectedSizeVal.textContent = `${val}px`;
        if (state.beads[state.selectedIndex]) {
          state.beads[state.selectedIndex].size = val;
          renderStudio();
          renderHeroPreview();
        }
      });
    }

    // String style select
    if (stringSelectEl) {
      stringSelectEl.addEventListener('change', (e) => {
        state.stringStyle = e.target.value;
        renderStudio();
      });
    }

    // Add Bead Button
    const addBtn = document.getElementById('studioAddBeadBtn');
    if (addBtn) {
      addBtn.addEventListener('click', () => {
        if (state.beads.length >= 32) {
          showToast('Maximum 32 beads allowed for design balance.');
          return;
        }
        state.beads.splice(state.selectedIndex + 1, 0, {
          shape: state.currentShape,
          color: state.currentColor,
          size: state.beadSize
        });
        state.selectedIndex++;
        renderStudio();
        renderHeroPreview();
        showToast('Bead added!');
      });
    }

    // Starter Beads button (from empty state)
    const starterBtn = document.getElementById('studioAddStarterBtn');
    if (starterBtn) {
      starterBtn.addEventListener('click', () => {
        loadPreset('azure');
      });
    }

    // Remove Selected Bead Button
    const removeBtn = document.getElementById('studioRemoveBeadBtn');
    if (removeBtn) {
      removeBtn.addEventListener('click', () => {
        if (state.beads.length === 0) return;
        state.beads.splice(state.selectedIndex, 1);
        if (state.selectedIndex >= state.beads.length) {
          state.selectedIndex = Math.max(0, state.beads.length - 1);
        }
        renderStudio();
        renderHeroPreview();
        showToast('Selected bead removed.');
      });
    }

    // Move Left (reorder)
    const moveLeftBtn = document.getElementById('studioMoveLeftBtn');
    if (moveLeftBtn) {
      moveLeftBtn.addEventListener('click', () => {
        if (state.beads.length <= 1) return;
        const target = (state.selectedIndex - 1 + state.beads.length) % state.beads.length;
        const temp = state.beads[state.selectedIndex];
        state.beads[state.selectedIndex] = state.beads[target];
        state.beads[target] = temp;
        state.selectedIndex = target;
        renderStudio();
        renderHeroPreview();
      });
    }

    // Move Right (reorder)
    const moveRightBtn = document.getElementById('studioMoveRightBtn');
    if (moveRightBtn) {
      moveRightBtn.addEventListener('click', () => {
        if (state.beads.length <= 1) return;
        const target = (state.selectedIndex + 1) % state.beads.length;
        const temp = state.beads[state.selectedIndex];
        state.beads[state.selectedIndex] = state.beads[target];
        state.beads[target] = temp;
        state.selectedIndex = target;
        renderStudio();
        renderHeroPreview();
      });
    }

    // Random Design Button
    const randomBtn = document.getElementById('studioRandomBtn');
    if (randomBtn) {
      randomBtn.addEventListener('click', generateRandomDesign);
    }

    // Reset Design Button
    const resetBtn = document.getElementById('studioResetBtn');
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        loadPreset('azure');
      });
    }

    // Clear Design Button
    const clearBtn = document.getElementById('studioClearBtn');
    if (clearBtn) {
      clearBtn.addEventListener('click', () => {
        if (confirm('Clear the entire bead design?')) {
          state.beads = [];
          state.selectedIndex = 0;
          renderStudio();
          renderHeroPreview();
          showToast('Design cleared.');
        }
      });
    }

    // Rotation Animation Toggle
    const rotateBtn = document.getElementById('studioRotateToggleBtn');
    if (rotateBtn) {
      rotateBtn.addEventListener('click', () => {
        state.isRotating = !state.isRotating;
        rotateBtn.classList.toggle('active', state.isRotating);
        if (state.isRotating) {
          startRotation();
          showToast('Live rotation started.');
        } else {
          stopRotation();
          showToast('Live rotation paused.');
        }
      });
    }

    // Download PNG Button
    const downloadBtn = document.getElementById('studioDownloadPngBtn');
    if (downloadBtn) {
      downloadBtn.addEventListener('click', exportDesignAsPng);
    }

    // Copy Summary Button
    const copySummaryBtn = document.getElementById('studioCopySummaryBtn');
    if (copySummaryBtn) {
      copySummaryBtn.addEventListener('click', copyDesignSummary);
    }

    // Preset buttons in sidebar
    document.querySelectorAll('.preset-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const key = btn.getAttribute('data-preset');
        loadPreset(key);
      });
    });

    // Hero pattern chips
    document.querySelectorAll('.pattern-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        document.querySelectorAll('.pattern-chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        const presetKey = chip.getAttribute('data-preset');
        loadPreset(presetKey);
      });
    });
  }

  // Generate Balanced Random Design
  function generateRandomDesign() {
    const shapes = ['sphere', 'oval', 'facet', 'cube', 'star', 'heart', 'spacer'];
    const count = 12 + Math.floor(Math.random() * 8); // 12-20 beads
    const pickedColors = [];
    for (let c = 0; c < 3; c++) {
      pickedColors.push(COLOR_PALETTE[Math.floor(Math.random() * COLOR_PALETTE.length)].hex);
    }
    const newBeads = [];
    for (let i = 0; i < count; i++) {
      const isSpacer = i % 2 === 1 && Math.random() > 0.4;
      newBeads.push({
        shape: isSpacer ? 'spacer' : shapes[Math.floor(Math.random() * shapes.length)],
        color: isSpacer ? '#D4AF37' : pickedColors[Math.floor(Math.random() * pickedColors.length)],
        size: isSpacer ? 16 : 20 + Math.floor(Math.random() * 6)
      });
    }
    state.beads = newBeads;
    state.selectedIndex = 0;
    renderStudio();
    renderHeroPreview();
    showToast('Generated fresh random design pattern!');
  }

  // Rotation Animation Loop
  function startRotation() {
    if (state.animationFrameId) cancelAnimationFrame(state.animationFrameId);
    function loop() {
      if (!state.isRotating) return;
      state.rotationAngle = (state.rotationAngle + 0.4) % 360;
      renderStudio();
      renderHeroPreview();
      state.animationFrameId = requestAnimationFrame(loop);
    }
    loop();
  }

  function stopRotation() {
    if (state.animationFrameId) {
      cancelAnimationFrame(state.animationFrameId);
      state.animationFrameId = null;
    }
  }

  // Export Design as real PNG Image
  function exportDesignAsPng() {
    if (state.beads.length === 0) {
      showToast('Cannot export an empty design.');
      return;
    }

    const canvas = document.createElement('canvas');
    const width = 800;
    const height = 800;
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');

    // Background
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, width, height);

    // Subtle radial background gradient
    const bgGrad = ctx.createRadialGradient(width / 2, height / 2, 50, width / 2, height / 2, width / 2);
    bgGrad.addColorStop(0, '#FFFFFF');
    bgGrad.addColorStop(1, '#F1F5F9');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, width, height);

    // Header branding on exported image
    ctx.fillStyle = '#1565C0';
    ctx.font = 'bold 24px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Arshed Web Studio — Custom Bracelet Design', width / 2, 50);

    ctx.fillStyle = '#64748B';
    ctx.font = '14px sans-serif';
    ctx.fillText(`Total Beads: ${state.beads.length}  |  Generated with Interactive Product Studio`, width / 2, 75);

    const cx = width / 2;
    const cy = height / 2 + 15;
    const radius = 260;
    const count = state.beads.length;

    // String circle
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.lineWidth = 6;
    ctx.strokeStyle = state.stringStyle === 'gold' ? '#D4AF37' : (state.stringStyle === 'braided' ? '#8D6E63' : '#94A3B8');
    ctx.stroke();

    // Draw Beads
    state.beads.forEach((bead, i) => {
      const angle = (i / count) * 2 * Math.PI - Math.PI / 2 + (state.rotationAngle * Math.PI / 180);
      const bx = cx + radius * Math.cos(angle);
      const by = cy + radius * Math.sin(angle);
      const beadRadius = (bead.size || 22) * 1.5;

      ctx.save();
      ctx.translate(bx, by);

      // Shadow
      ctx.shadowColor = 'rgba(0, 0, 0, 0.25)';
      ctx.shadowBlur = 12;
      ctx.shadowOffsetX = 3;
      ctx.shadowOffsetY = 6;

      // Radial Gradient for 3D sphere look
      const grad = ctx.createRadialGradient(-beadRadius * 0.35, -beadRadius * 0.35, beadRadius * 0.1, 0, 0, beadRadius);
      grad.addColorStop(0, '#FFFFFF');
      grad.addColorStop(0.3, bead.color);
      grad.addColorStop(1, adjustBrightness(bead.color, -50));
      ctx.fillStyle = grad;

      ctx.beginPath();
      ctx.arc(0, 0, beadRadius, 0, Math.PI * 2);
      ctx.fill();

      // Bead index text
      ctx.shadowColor = 'transparent';
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 12px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(i + 1, 0, 0);

      ctx.restore();
    });

    // Footer Watermark
    ctx.fillStyle = '#94A3B8';
    ctx.font = '12px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Design verified at arshedwebstudio.com  •  Freelancer.com Portfolio Project', width / 2, height - 30);

    // Trigger download
    const link = document.createElement('a');
    link.download = `arshed_studio_bead_design_${Date.now()}.png`;
    link.href = canvas.toDataURL('image/png');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    showToast('PNG design image exported successfully!');
  }

  // Copy Design Summary to Clipboard
  function copyDesignSummary() {
    if (state.beads.length === 0) {
      showToast('No design data to copy.');
      return;
    }

    const shapeSummary = {};
    const colorSummary = {};
    state.beads.forEach(b => {
      shapeSummary[b.shape] = (shapeSummary[b.shape] || 0) + 1;
      colorSummary[b.color] = (colorSummary[b.color] || 0) + 1;
    });

    const summaryText = [
      '==========================================',
      'ARSHED WEB STUDIO — BEAD DESIGN SPECIFICATION',
      '==========================================',
      `Total Beads: ${state.beads.length}`,
      `String Type: ${state.stringStyle}`,
      `Estimated Circumference: ${estLengthEl ? estLengthEl.textContent : 'N/A'}`,
      '',
      '--- Bead Sequence ---',
      state.beads.map((b, i) => `#${i + 1}: ${b.shape.toUpperCase()} (${b.color}, ${b.size}px)`).join('\n'),
      '',
      '--- Shape Breakdown ---',
      Object.entries(shapeSummary).map(([s, n]) => `${s}: ${n}`).join(', '),
      '',
      'Generated with Arshed Web Studio Interactive Emulator',
      'https://www.freelancer.com/u/arshedwebstudio',
      '=========================================='
    ].join('\n');

    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(summaryText).then(() => {
        showToast('Design summary copied to clipboard!');
      }).catch(() => {
        fallbackCopy(summaryText);
      });
    } else {
      fallbackCopy(summaryText);
    }
  }

  function fallbackCopy(text) {
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    try {
      document.execCommand('copy');
      showToast('Design summary copied to clipboard!');
    } catch (e) {
      alert('Design Summary:\n\n' + text);
    }
    document.body.removeChild(ta);
  }

  // Star Points Helper for SVG
  function getStarPoints(cx, cy, spikes, outerRadius, innerRadius) {
    let rot = (Math.PI / 2) * 3;
    let x = cx;
    let y = cy;
    const step = Math.PI / spikes;
    const points = [];

    for (let i = 0; i < spikes; i++) {
      x = cx + Math.cos(rot) * outerRadius;
      y = cy + Math.sin(rot) * outerRadius;
      points.push(`${x},${y}`);
      rot += step;

      x = cx + Math.cos(rot) * innerRadius;
      y = cy + Math.sin(rot) * innerRadius;
      points.push(`${x},${y}`);
      rot += step;
    }
    return points.join(' ');
  }

  // Adjust hex brightness helper
  function adjustBrightness(hex, percent) {
    hex = hex.replace(/^#/, '');
    if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
    const num = parseInt(hex, 16);
    let r = (num >> 16) + percent;
    let g = ((num >> 8) & 0x00FF) + percent;
    let b = (num & 0x0000FF) + percent;
    r = Math.min(255, Math.max(0, r));
    g = Math.min(255, Math.max(0, g));
    b = Math.min(255, Math.max(0, b));
    return '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
  }

  function capitalize(s) {
    return s ? s.charAt(0).toUpperCase() + s.slice(1) : '';
  }

  function showToast(msg) {
    const toast = document.getElementById('globalToast');
    if (!toast) return;
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => {
      toast.classList.remove('show');
    }, 2800);
  }

  // Expose to window for external callers
  window.ArshedSimulator = {
    init,
    loadPreset,
    generateRandomDesign,
    exportDesignAsPng,
    copyDesignSummary
  };

  // Initialize on DOMContentLoaded
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
