/**
 * Arshed Web Studio - Portfolio Projects Interactive Demos & Case Studies
 * Provides interactive modals for School Management Dashboard, Local News Portal,
 * and comprehensive Case Study documentation modals.
 */

(function () {
  'use strict';

  // Sample School Data
  const schoolData = {
    students: [
      { id: 'ST-101', name: 'Tanvir Hossain', grade: 'Grade 10', roll: '01', status: 'Present', attendance: '96%' },
      { id: 'ST-102', name: 'Nusrat Jahan', grade: 'Grade 10', roll: '02', status: 'Present', attendance: '98%' },
      { id: 'ST-103', name: 'Arafat Rahman', grade: 'Grade 9', roll: '05', status: 'Late', attendance: '88%' },
      { id: 'ST-104', name: 'Farhana Akhter', grade: 'Grade 10', roll: '03', status: 'Present', attendance: '95%' },
      { id: 'ST-105', name: 'Sabbir Ahmed', grade: 'Grade 9', roll: '12', status: 'Absent', attendance: '82%' },
      { id: 'ST-106', name: 'Mehedi Hasan', grade: 'Grade 8', roll: '04', status: 'Present', attendance: '94%' },
      { id: 'ST-107', name: 'Sumaiya Islam', grade: 'Grade 8', roll: '08', status: 'Present', attendance: '99%' }
    ],
    teachers: [
      { id: 'TC-01', name: 'Dr. Rafiqul Islam', dept: 'Mathematics', role: 'Head Teacher', status: 'On Campus' },
      { id: 'TC-02', name: 'Shirin Sultana', dept: 'English Literature', role: 'Senior Teacher', status: 'In Class' },
      { id: 'TC-03', name: 'Mizanur Rahman', dept: 'Physics & Science', role: 'Assistant Teacher', status: 'On Campus' },
      { id: 'TC-04', name: 'Nasrin Parvin', dept: 'Computer Science', role: 'Lab Instructor', status: 'In Lab' }
    ],
    notices: [
      { id: 1, title: 'Annual Sports Day Schedule Announced', date: 'Oct 14, 2026', tag: 'Event', content: 'Track and field events commence next Monday at 9:00 AM on the central playground.' },
      { id: 2, title: 'Term Examination Advisory for Grades 8-10', date: 'Oct 12, 2026', tag: 'Academic', content: 'Admit cards will be distributed from the administrative office starting Wednesday.' },
      { id: 3, title: 'Science Club Robotics Workshop', date: 'Oct 10, 2026', tag: 'Co-Curricular', content: 'Hands-on Arduino and sensor programming session in the STEM laboratory.' }
    ]
  };

  // Sample News Portal Data
  const newsData = [
    {
      id: 1,
      title: 'City Council Approves High-Speed Green Metro Expansion to Riverfront',
      category: 'Community',
      time: '2 hours ago',
      author: 'City Desk',
      summary: 'The urban transit authority has secured final civic approval to extend the rapid transit corridor by 8 kilometers with zero-emission electric rolling stock.',
      content: 'The urban transit authority has secured final civic approval to extend the rapid transit corridor by 8 kilometers with zero-emission electric rolling stock. The multi-phase project aims to decrease daily commuter road congestion by an estimated 34% while connecting underserved residential suburbs with prime employment districts.\n\nCivic engineers confirmed that ground testing will begin in November, with state-of-the-art pedestrian interchanges and solar-paneled terminal facilities.'
    },
    {
      id: 2,
      title: 'Local Tech Incubator Launches Digital Skills Accelerator for Students',
      category: 'Technology',
      time: '4 hours ago',
      author: 'Tech Reporter',
      summary: 'Over 200 secondary and college students will gain hands-on training in web design, UI/UX architecture, and open-source tooling.',
      content: 'Over 200 secondary and college students will gain hands-on training in web design, UI/UX architecture, and open-source tooling through a newly announced grant partnership.\n\nThe curriculum features real-world project portfolios, mentorship from practicing freelance software engineers, and community workshops on modern frontend development.'
    },
    {
      id: 3,
      title: 'Regional Farmers Market Expands Organic Produce Hub for Autumn',
      category: 'Business',
      time: '6 hours ago',
      author: 'Agriculture Correspondent',
      summary: 'Local organic growers celebrate record harvests and unveil contactless digital payment options at community stalls.',
      content: 'Local organic growers celebrate record harvests and unveil contactless digital payment options at community stalls throughout the downtown square.\n\nOrganizers noted a 45% increase in weekend visitors seeking fresh farm-to-table vegetables, organic honey, and sustainable packaging.'
    },
    {
      id: 4,
      title: 'District Championship: Youth Football Team Clinches Gold in Final Minutes',
      category: 'Sports',
      time: '8 hours ago',
      author: 'Sports Desk',
      summary: 'A dramatic header in the 89th minute sealed a historic 2-1 victory before a crowd of 3,500 roaring local supporters.',
      content: 'A dramatic header in the 89th minute sealed a historic 2-1 victory before a crowd of 3,500 roaring local supporters at Municipal Stadium.\n\nThe team captain praised disciplined squad training and defensive coordination during tense injury-time pressure.'
    }
  ];

  // Case Studies Content
  const caseStudies = {
    'product-studio': {
      title: 'Case Study: Interactive Product Design Studio',
      subtitle: 'Dynamic Jewelry & Bead Customizer with Instant Vector Graphics & PNG Export',
      problem: 'Online personalized jewelry shops frequently rely on static image galleries where customers cannot visualize how customized bead color patterns, gemstone shapes, or cord styles harmonize before ordering.',
      approach: 'Engineered an accessible, pure vanilla JavaScript canvas powered by scalable vector graphics (SVG). The coordinate positioning calculates circular trigonometric angles (cx + r*cos(θ), cy + r*sin(θ)) in real time, enabling fluid bead insertion, deletion, reordering, and sizing without heavy framework overhead.',
      techStack: ['HTML5 SVG', 'HTML5 Canvas API', 'Vanilla JavaScript (ES6+)', 'Modern CSS3 Custom Properties'],
      features: [
        'Real-time parametric SVG rendering with realistic radial gradient specular highlights',
        'Multi-shape geometry (Sphere, Oval, Faceted Diamond, Cube, Star, Heart, Spacer)',
        'Offscreen Canvas PNG image export engine for instantaneous client-side download',
        'Structured clipboard JSON and formatted text specification generation',
        'Lightweight, zero third-party dependencies for rapid mobile load times'
      ],
      disclaimer: 'Demonstration concept project developed to demonstrate interactive frontend development, SVG mathematical transformations, and DOM performance.'
    },
    'school-dashboard': {
      title: 'Case Study: School Management Dashboard UI',
      subtitle: 'Responsive Multi-View Educational Portal for Academic Staff & Administrators',
      problem: 'Administrative school systems often struggle with cluttered, legacy desktop-only user interfaces that overwhelm teachers on tablets and smartphones during daily attendance marking and announcements.',
      approach: 'Designed a clean, modular dashboard layout featuring high-contrast summary metric cards, tabbed views for attendance overview, searchable student rosters, faculty directories, and an instant notice broadcasting board.',
      techStack: ['Semantic HTML5', 'Responsive CSS Grid & Flexbox', 'Dynamic DOM Manipulation', 'Accessible Tab Patterns'],
      features: [
        'Live summary metric cards showcasing student and faculty presence ratios',
        'Real-time instant text search filter across student records and grade tiers',
        'Interactive notice broadcast board with dynamic item creation',
        'Clean tabular layout that gracefully scrolls horizontally on mobile displays',
        'Semantic color coding for student status (Present, Late, Absent)'
      ],
      disclaimer: 'Demonstration UI project with simulated data created to demonstrate dashboard architecture, tabular filtering, and responsive interface workflows.'
    },
    'news-portal': {
      title: 'Case Study: Local News Portal ("Metro Pulse")',
      subtitle: 'Fast-Loading Responsive Editorial Portal with Categorical Filtering & Breaking Ticker',
      problem: 'Regional news publications often suffer from sluggish loading speeds, intrusive layout shifts, and poor readability on compact smartphone screens.',
      approach: 'Created an editorial web layout inspired by modern typography-forward newsrooms. Features a high-visibility breaking news ticker, instant category filtering pills without full page reloads, and an accessible story reading overlay.',
      techStack: ['HTML5 Semantic Articles', 'CSS3 Modern Flex & Grid', 'Client-side Category Filter', 'Accessible Modal Patterns'],
      features: [
        'Breaking news banner with rotating community headlines',
        'Instant zero-latency category filtering (Politics, Business, Technology, Community, Sports)',
        'Full-text live search across headline archives',
        'Responsive article cards with metadata (timestamp, author, reading time)',
        'Fast initial load with minimal layout shifts'
      ],
      disclaimer: 'Demonstration concept portal populated with sample journalistic content to showcase responsive publication typography and layout.'
    }
  };

  // Initialize
  function init() {
    setupProjectTriggers();
    setupModalCloseHandlers();
  }

  // Setup click triggers for cards
  function setupProjectTriggers() {
    // Open Demo buttons
    document.querySelectorAll('[data-action="open-demo"]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const projectKey = btn.getAttribute('data-project');
        if (projectKey === 'product-studio') {
          // Scroll smoothly to studio section
          const studioEl = document.getElementById('studio');
          if (studioEl) {
            studioEl.scrollIntoView({ behavior: 'smooth' });
            // Highlight studio border briefly
            const wrapper = studioEl.querySelector('.studio-workspace-wrapper');
            if (wrapper) {
              wrapper.style.borderColor = 'var(--primary)';
              wrapper.style.boxShadow = '0 0 0 4px rgba(21, 101, 192, 0.25)';
              setTimeout(() => {
                wrapper.style.borderColor = '';
                wrapper.style.boxShadow = '';
              }, 1800);
            }
          }
        } else if (projectKey === 'school-dashboard') {
          openSchoolDashboardModal();
        } else if (projectKey === 'news-portal') {
          openNewsPortalModal();
        }
      });
    });

    // View Case Study buttons
    document.querySelectorAll('[data-action="view-case-study"]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const projectKey = btn.getAttribute('data-project');
        openCaseStudyModal(projectKey);
      });
    });
  }

  // School Dashboard Modal
  function openSchoolDashboardModal() {
    const modal = document.getElementById('schoolDashboardModal');
    if (!modal) return;
    renderSchoolDashboardContent(modal);
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function renderSchoolDashboardContent(modal) {
    const body = modal.querySelector('.modal-body');
    if (!body) return;

    body.innerHTML = `
      <div class="project-disclaimer">
        <strong>Portfolio Demonstration Notice:</strong> This interactive school portal runs with simulated local records to showcase UI dashboard architecture and filtering.
      </div>

      <!-- Metric Cards -->
      <div class="dash-metrics-grid">
        <div class="dash-metric-card">
          <div class="dash-metric-num">94.2%</div>
          <div class="dash-metric-title">Student Attendance Today</div>
        </div>
        <div class="dash-metric-card">
          <div class="dash-metric-num">98.0%</div>
          <div class="dash-metric-title">Faculty Presence</div>
        </div>
        <div class="dash-metric-card">
          <div class="dash-metric-num">1,240</div>
          <div class="dash-metric-title">Total Enrolled</div>
        </div>
        <div class="dash-metric-card">
          <div class="dash-metric-num">5</div>
          <div class="dash-metric-title">Active Notices</div>
        </div>
      </div>

      <!-- Tabs Navigation -->
      <div class="dashboard-nav-tabs">
        <button class="dash-tab-btn active" data-tab="students">Students Roster</button>
        <button class="dash-tab-btn" data-tab="teachers">Faculty Directory</button>
        <button class="dash-tab-btn" data-tab="notices">Notice Board</button>
      </div>

      <!-- Tab Content Area -->
      <div id="schoolTabContentArea"></div>
    `;

    // Render Students tab initially
    renderSchoolTab('students');

    // Tab click listeners
    modal.querySelectorAll('.dash-tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        modal.querySelectorAll('.dash-tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const tab = btn.getAttribute('data-tab');
        renderSchoolTab(tab);
      });
    });
  }

  function renderSchoolTab(tab) {
    const container = document.getElementById('schoolTabContentArea');
    if (!container) return;

    if (tab === 'students') {
      container.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem; flex-wrap:wrap; gap:0.5rem;">
          <input type="text" id="schoolStudentSearch" placeholder="Search student name or roll..." class="search-input" style="max-width:300px;">
          <span style="font-size:0.85rem; color:var(--text-subtle);">Showing ${schoolData.students.length} demo records</span>
        </div>
        <div class="dash-table-wrap">
          <table class="dash-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Student Name</th>
                <th>Grade</th>
                <th>Roll</th>
                <th>Status</th>
                <th>Attendance</th>
              </tr>
            </thead>
            <tbody id="schoolStudentTbody"></tbody>
          </table>
        </div>
      `;

      function updateRows(filterText = '') {
        const tbody = document.getElementById('schoolStudentTbody');
        if (!tbody) return;
        const filtered = schoolData.students.filter(s =>
          s.name.toLowerCase().includes(filterText.toLowerCase()) ||
          s.roll.includes(filterText) ||
          s.grade.toLowerCase().includes(filterText.toLowerCase())
        );

        if (filtered.length === 0) {
          tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:1.5rem; color:var(--text-subtle);">No matching student records found.</td></tr>`;
          return;
        }

        tbody.innerHTML = filtered.map(s => {
          let badgeColor = '#2E7D32';
          if (s.status === 'Late') badgeColor = '#EF6C00';
          if (s.status === 'Absent') badgeColor = '#C62828';

          return `
            <tr>
              <td><strong>${s.id}</strong></td>
              <td>${s.name}</td>
              <td>${s.grade}</td>
              <td>#${s.roll}</td>
              <td><span style="display:inline-block; padding:0.2rem 0.6rem; border-radius:999px; font-size:0.75rem; font-weight:700; color:white; background-color:${badgeColor};">${s.status}</span></td>
              <td>${s.attendance}</td>
            </tr>
          `;
        }).join('');
      }

      updateRows();

      const searchInput = document.getElementById('schoolStudentSearch');
      if (searchInput) {
        searchInput.addEventListener('input', (e) => updateRows(e.target.value));
      }
    } else if (tab === 'teachers') {
      container.innerHTML = `
        <div class="dash-table-wrap">
          <table class="dash-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Teacher Name</th>
                <th>Department</th>
                <th>Role</th>
                <th>Current Status</th>
              </tr>
            </thead>
            <tbody>
              ${schoolData.teachers.map(t => `
                <tr>
                  <td><strong>${t.id}</strong></td>
                  <td>${t.name}</td>
                  <td>${t.dept}</td>
                  <td>${t.role}</td>
                  <td><span style="display:inline-block; padding:0.2rem 0.6rem; border-radius:999px; font-size:0.75rem; font-weight:700; color:var(--primary); background-color:var(--primary-light);">${t.status}</span></td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;
    } else if (tab === 'notices') {
      container.innerHTML = `
        <div style="display:flex; flex-direction:column; gap:1.25rem;">
          <div style="background-color:var(--surface); padding:1rem; border-radius:var(--radius-md); border:1px solid var(--border);">
            <div style="font-weight:700; font-size:0.95rem; margin-bottom:0.6rem; color:var(--text-main);">Broadcast New Notice (Interactive Demo)</div>
            <div style="display:flex; gap:0.5rem; flex-wrap:wrap;">
              <input type="text" id="newNoticeTitle" placeholder="Notice subject..." class="form-input" style="flex:1; min-width:200px;">
              <input type="text" id="newNoticeTag" placeholder="Tag (e.g. Academic, Sports)" class="form-input" style="width:160px;">
              <button class="btn btn-primary btn-sm" id="postNoticeBtn">Publish Notice</button>
            </div>
          </div>
          <div id="noticeListContainer" style="display:flex; flex-direction:column; gap:0.75rem;">
            ${renderNoticesList()}
          </div>
        </div>
      `;

      const postBtn = document.getElementById('postNoticeBtn');
      if (postBtn) {
        postBtn.addEventListener('click', () => {
          const titleInput = document.getElementById('newNoticeTitle');
          const tagInput = document.getElementById('newNoticeTag');
          if (!titleInput.value.trim()) {
            alert('Please enter a notice subject.');
            return;
          }
          schoolData.notices.unshift({
            id: Date.now(),
            title: titleInput.value.trim(),
            date: 'Today',
            tag: tagInput.value.trim() || 'General',
            content: 'Notice published via School Management Dashboard interactive demo.'
          });
          titleInput.value = '';
          tagInput.value = '';
          const listEl = document.getElementById('noticeListContainer');
          if (listEl) listEl.innerHTML = renderNoticesList();
        });
      }
    }
  }

  function renderNoticesList() {
    return schoolData.notices.map(n => `
      <div style="padding:1rem; background-color:var(--surface); border-radius:var(--radius-md); border-left:4px solid var(--primary); border:1px solid var(--border); border-left-width:4px;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.35rem;">
          <span style="font-size:0.75rem; font-weight:700; text-transform:uppercase; color:var(--primary); background-color:var(--primary-light); padding:0.15rem 0.5rem; border-radius:var(--radius-full);">${n.tag}</span>
          <span style="font-size:0.78rem; color:var(--text-subtle);">${n.date}</span>
        </div>
        <div style="font-weight:700; font-size:1rem; color:var(--text-main); margin-bottom:0.3rem;">${n.title}</div>
        <div style="font-size:0.88rem; color:var(--text-muted);">${n.content}</div>
      </div>
    `).join('');
  }

  // Local News Portal Modal
  function openNewsPortalModal() {
    const modal = document.getElementById('newsPortalModal');
    if (!modal) return;
    renderNewsPortalContent(modal);
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function renderNewsPortalContent(modal) {
    const body = modal.querySelector('.modal-body');
    if (!body) return;

    let selectedCat = 'All';
    let searchQuery = '';

    function renderPortal() {
      const filtered = newsData.filter(item => {
        const matchesCat = selectedCat === 'All' || item.category === selectedCat;
        const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          item.summary.toLowerCase().includes(searchQuery.toLowerCase());
        return matchesCat && matchesSearch;
      });

      const featured = filtered[0] || newsData[0];
      const feed = filtered.slice(1);

      body.innerHTML = `
        <div class="project-disclaimer">
          <strong>Portfolio Demonstration Notice:</strong> Metro Pulse is a sample editorial news portal layout built to demonstrate responsive publishing layouts and real-time category filtering.
        </div>

        <!-- Breaking Ticker -->
        <div class="news-header-ticker">
          <span style="font-weight:800; text-transform:uppercase; font-size:0.72rem; background:rgba(0,0,0,0.25); padding:0.1rem 0.4rem; border-radius:3px;">Breaking</span>
          <span>City Council Approves High-Speed Green Metro Expansion to Riverfront Corridor</span>
        </div>

        <!-- Search & Category Bar -->
        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:0.75rem; border-bottom:1px solid var(--border); padding-bottom:0.75rem;">
          <div class="news-categories-nav">
            ${['All', 'Community', 'Technology', 'Business', 'Sports'].map(cat => `
              <button class="news-cat-chip ${selectedCat === cat ? 'active' : ''}" data-cat="${cat}">${cat}</button>
            `).join('')}
          </div>
          <input type="text" id="newsPortalSearchInput" value="${searchQuery}" placeholder="Search articles..." class="search-input" style="max-width:240px; padding:0.4rem 0.75rem;">
        </div>

        <!-- News Content Grid -->
        <div class="news-cards-layout">
          <!-- Featured Story -->
          <div class="news-featured-card">
            <span style="font-size:0.75rem; font-weight:700; color:var(--primary); text-transform:uppercase;">${featured.category} • ${featured.time}</span>
            <h3 style="font-size:1.35rem; font-weight:800; color:var(--text-main); line-height:1.3;">${featured.title}</h3>
            <p style="font-size:0.92rem; color:var(--text-muted); line-height:1.6;">${featured.summary}</p>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-top:auto; padding-top:1rem; border-top:1px solid var(--border);">
              <span style="font-size:0.8rem; color:var(--text-subtle);">By ${featured.author}</span>
              <button class="btn btn-primary btn-sm read-article-btn" data-id="${featured.id}">Read Full Story</button>
            </div>
          </div>

          <!-- Feed List -->
          <div class="news-feed-list">
            <div style="font-size:0.85rem; font-weight:700; text-transform:uppercase; color:var(--text-subtle);">Latest Bulletins</div>
            ${feed.length > 0 ? feed.map(item => `
              <div class="news-feed-item read-article-btn" data-id="${item.id}">
                <div style="font-size:0.72rem; font-weight:700; color:var(--accent);">${item.category} • ${item.time}</div>
                <div style="font-size:0.95rem; font-weight:700; color:var(--text-main); margin:0.25rem 0;">${item.title}</div>
                <div style="font-size:0.82rem; color:var(--text-subtle);">${item.summary.substring(0, 85)}...</div>
              </div>
            `).join('') : '<div style="font-size:0.88rem; color:var(--text-subtle); padding:1rem;">No other articles in this filter.</div>'}
          </div>
        </div>
      `;

      // Category chip clicks
      modal.querySelectorAll('.news-cat-chip').forEach(chip => {
        chip.addEventListener('click', () => {
          selectedCat = chip.getAttribute('data-cat');
          renderPortal();
        });
      });

      // Search input
      const searchIn = document.getElementById('newsPortalSearchInput');
      if (searchIn) {
        searchIn.addEventListener('input', (e) => {
          searchQuery = e.target.value;
          renderPortal();
          const renewed = document.getElementById('newsPortalSearchInput');
          if (renewed) {
            renewed.focus();
            renewed.setSelectionRange(searchQuery.length, searchQuery.length);
          }
        });
      }

      // Read Full Story click
      modal.querySelectorAll('.read-article-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const id = parseInt(btn.getAttribute('data-id'), 10);
          const article = newsData.find(a => a.id === id);
          if (article) {
            showArticleReader(article);
          }
        });
      });
    }

    renderPortal();
  }

  function showArticleReader(article) {
    const readerModal = document.getElementById('caseStudyModal');
    if (!readerModal) return;
    const body = readerModal.querySelector('.modal-body');
    const titleEl = readerModal.querySelector('.modal-title');
    if (titleEl) titleEl.textContent = article.title;

    body.innerHTML = `
      <div style="font-size:0.85rem; color:var(--text-subtle); margin-bottom:1rem;">
        Category: <strong>${article.category}</strong> | Reported by: <strong>${article.author}</strong> | ${article.time}
      </div>
      <div style="font-size:1.05rem; line-height:1.75; color:var(--text-main); white-space:pre-line;">
        ${article.content}
      </div>
      <div style="margin-top:1.5rem; padding-top:1rem; border-top:1px solid var(--border);">
        <button class="btn btn-outline btn-sm" id="backToNewsBtn">← Back to News Portal</button>
      </div>
    `;

    readerModal.classList.add('active');

    const backBtn = document.getElementById('backToNewsBtn');
    if (backBtn) {
      backBtn.addEventListener('click', () => {
        readerModal.classList.remove('active');
      });
    }
  }

  // Case Study Modal
  function openCaseStudyModal(key) {
    const data = caseStudies[key];
    if (!data) return;

    const modal = document.getElementById('caseStudyModal');
    if (!modal) return;

    const titleEl = modal.querySelector('.modal-title');
    const bodyEl = modal.querySelector('.modal-body');

    if (titleEl) titleEl.textContent = data.title;

    bodyEl.innerHTML = `
      <div style="font-size:1.05rem; font-weight:600; color:var(--primary); margin-bottom:0.5rem;">${data.subtitle}</div>

      <div class="project-disclaimer">
        <strong>Honesty & Transparency:</strong> ${data.disclaimer}
      </div>

      <div style="display:flex; flex-direction:column; gap:1.25rem; margin-top:0.75rem;">
        <div>
          <h4 style="font-size:0.95rem; font-weight:700; color:var(--text-main); text-transform:uppercase; margin-bottom:0.4rem;">The Challenge & Objective</h4>
          <p style="font-size:0.92rem; color:var(--text-muted); line-height:1.6;">${data.problem}</p>
        </div>

        <div>
          <h4 style="font-size:0.95rem; font-weight:700; color:var(--text-main); text-transform:uppercase; margin-bottom:0.4rem;">Design & Technical Approach</h4>
          <p style="font-size:0.92rem; color:var(--text-muted); line-height:1.6;">${data.approach}</p>
        </div>

        <div>
          <h4 style="font-size:0.95rem; font-weight:700; color:var(--text-main); text-transform:uppercase; margin-bottom:0.5rem;">Key Architecture & Features</h4>
          <ul style="padding-left:1.25rem; font-size:0.9rem; color:var(--text-muted); display:flex; flex-direction:column; gap:0.4rem;">
            ${data.features.map(f => `<li>${f}</li>`).join('')}
          </ul>
        </div>

        <div>
          <h4 style="font-size:0.95rem; font-weight:700; color:var(--text-main); text-transform:uppercase; margin-bottom:0.5rem;">Technology Stack</h4>
          <div style="display:flex; flex-wrap:wrap; gap:0.5rem;">
            ${data.techStack.map(t => `<span class="tech-chip" style="font-size:0.8rem; padding:0.3rem 0.7rem; font-weight:600;">${t}</span>`).join('')}
          </div>
        </div>
      </div>
    `;

    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  // Close modals handling
  function setupModalCloseHandlers() {
    document.querySelectorAll('.modal-backdrop').forEach(modal => {
      // Close on background click
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          modal.classList.remove('active');
          document.body.style.overflow = '';
        }
      });

      // Close on close button
      const closeBtn = modal.querySelector('.modal-close-btn');
      if (closeBtn) {
        closeBtn.addEventListener('click', () => {
          modal.classList.remove('active');
          document.body.style.overflow = '';
        });
      }
    });

    // Close on Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        document.querySelectorAll('.modal-backdrop.active').forEach(modal => {
          modal.classList.remove('active');
        });
        document.body.style.overflow = '';
      }
    });
  }

  // Expose
  window.ArshedDemos = {
    openSchoolDashboardModal,
    openNewsPortalModal,
    openCaseStudyModal
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
